import JSZip from 'jszip';
import {
  FIXED_ANDROID_MANIFEST_XML,
  FIXED_LOCKFREE_RINGBUFFER_H,
  FIXED_MIXER_ENGINE_CPP,
} from './androidFixedTemplates';

const ROOT_BUILD_GRADLE_KTS = `plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
`;

const GRADLE_WRAPPER_PROPERTIES = `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.7-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`;

const SETTINGS_GRADLE_KTS = `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "AudioMasterPro"
include(":app")
`;

const GRADLE_PROPERTIES = `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
android.nonTransitiveRClass=true
`;

const STRINGS_XML = `<resources>
    <string name="app_name">AudioMaster Pro</string>
</resources>
`;

const ACTIVITY_MAIN_XML = `<?xml version="1.0" encoding="utf-8"?>
<ScrollView xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="#0B0C10"
    android:fillViewport="true">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:padding="12dp">

        <!-- Header -->
        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:background="#13151B"
            android:gravity="center_vertical"
            android:orientation="horizontal"
            android:padding="10dp">

            <TextView
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="AudioMaster Pro"
                android:textColor="#10B981"
                android:textSize="16sp"
                android:textStyle="bold" />

            <ToggleButton
                android:id="@+id/btnRecord"
                android:layout_width="wrap_content"
                android:layout_height="44dp"
                android:backgroundTint="#DC2626"
                android:textColor="#FFFFFF"
                android:textOff="REC WAV"
                android:textOn="STOP REC"
                android:textSize="12sp" />
        </LinearLayout>

        <!-- YouTube URL + Embedded Player -->
        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="8dp"
            android:orientation="horizontal">

            <EditText
                android:id="@+id/editYoutubeUrl"
                android:layout_width="0dp"
                android:layout_height="48dp"
                android:layout_weight="1"
                android:background="#13151B"
                android:hint="Link / ID Video YouTube..."
                android:paddingHorizontal="12dp"
                android:textColor="#FFFFFF"
                android:textColorHint="#64748B"
                android:textSize="13sp" />

            <Button
                android:id="@+id/btnLoadYt"
                android:layout_width="wrap_content"
                android:layout_height="48dp"
                android:layout_marginStart="8dp"
                android:backgroundTint="#10B981"
                android:text="Putar"
                android:textColor="#0B0C10" />
        </LinearLayout>

        <WebView
            android:id="@+id/youtubeWebView"
            android:layout_width="match_parent"
            android:layout_height="200dp"
            android:layout_marginTop="8dp" />

        <!-- DSP Controls -->
        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="10dp"
            android:background="#13151B"
            android:gravity="center_vertical"
            android:orientation="horizontal"
            android:padding="10dp">

            <ToggleButton
                android:id="@+id/btnComp"
                android:layout_width="wrap_content"
                android:layout_height="44dp"
                android:checked="true"
                android:textOff="COMP OFF"
                android:textOn="COMP ON"
                android:textSize="11sp" />

            <ToggleButton
                android:id="@+id/btnHarmony"
                android:layout_width="wrap_content"
                android:layout_height="44dp"
                android:layout_marginStart="6dp"
                android:textOff="HARMONY OFF"
                android:textOn="HARMONY ON"
                android:textSize="11sp" />

            <Spinner
                android:id="@+id/spinnerKey"
                android:layout_width="0dp"
                android:layout_height="44dp"
                android:layout_marginStart="6dp"
                android:layout_weight="1"
                android:background="#1E293B" />
        </LinearLayout>

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="6dp"
            android:background="#13151B"
            android:gravity="center_vertical"
            android:orientation="horizontal"
            android:padding="10dp">

            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="Delay"
                android:textColor="#E2E8F0"
                android:textSize="12sp" />

            <SeekBar
                android:id="@+id/seekDelay"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_marginStart="8dp"
                android:layout_weight="1"
                android:max="100"
                android:progress="25" />
        </LinearLayout>

        <!-- 3-Band EQ -->
        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="8dp"
            android:background="#13151B"
            android:orientation="vertical"
            android:padding="10dp">

            <Spinner
                android:id="@+id/spinnerEqChannel"
                android:layout_width="match_parent"
                android:layout_height="44dp"
                android:background="#1E293B" />

            <TextView android:layout_width="wrap_content" android:layout_height="wrap_content" android:layout_marginTop="6dp" android:text="LOW (100Hz)" android:textColor="#38BDF8" android:textSize="11sp" />
            <SeekBar android:id="@+id/seekEqLow" android:layout_width="match_parent" android:layout_height="wrap_content" android:max="24" android:progress="12" />

            <TextView android:layout_width="wrap_content" android:layout_height="wrap_content" android:layout_marginTop="4dp" android:text="MID (1kHz)" android:textColor="#34D399" android:textSize="11sp" />
            <SeekBar android:id="@+id/seekEqMid" android:layout_width="match_parent" android:layout_height="wrap_content" android:max="24" android:progress="12" />

            <TextView android:layout_width="wrap_content" android:layout_height="wrap_content" android:layout_marginTop="4dp" android:text="HIGH (8kHz)" android:textColor="#FBBF24" android:textSize="11sp" />
            <SeekBar android:id="@+id/seekEqHigh" android:layout_width="match_parent" android:layout_height="wrap_content" android:max="24" android:progress="12" />
        </LinearLayout>

        <!-- 5-Channel Faders -->
        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="8dp"
            android:background="#13151B"
            android:orientation="vertical"
            android:padding="10dp">

            <TextView android:layout_width="wrap_content" android:layout_height="wrap_content" android:text="CH 1: VOCAL" android:textColor="#38BDF8" android:textSize="12sp" android:textStyle="bold" />
            <SeekBar android:id="@+id/faderCh1" android:layout_width="match_parent" android:layout_height="wrap_content" android:max="120" android:progress="100" />

            <TextView android:layout_width="wrap_content" android:layout_height="wrap_content" android:layout_marginTop="6dp" android:text="CH 2: HARMONY / MIC 2" android:textColor="#34D399" android:textSize="12sp" android:textStyle="bold" />
            <SeekBar android:id="@+id/faderCh2" android:layout_width="match_parent" android:layout_height="wrap_content" android:max="120" android:progress="85" />

            <TextView android:layout_width="wrap_content" android:layout_height="wrap_content" android:layout_marginTop="6dp" android:text="CH 3: INST 1" android:textColor="#FBBF24" android:textSize="12sp" android:textStyle="bold" />
            <SeekBar android:id="@+id/faderCh3" android:layout_width="match_parent" android:layout_height="wrap_content" android:max="120" android:progress="90" />

            <TextView android:layout_width="wrap_content" android:layout_height="wrap_content" android:layout_marginTop="6dp" android:text="CH 4: INST 2" android:textColor="#FB923C" android:textSize="12sp" android:textStyle="bold" />
            <SeekBar android:id="@+id/faderCh4" android:layout_width="match_parent" android:layout_height="wrap_content" android:max="120" android:progress="85" />

            <TextView android:layout_width="wrap_content" android:layout_height="wrap_content" android:layout_marginTop="6dp" android:text="CH 5: YOUTUBE" android:textColor="#F87171" android:textSize="12sp" android:textStyle="bold" />
            <SeekBar android:id="@+id/faderYoutube" android:layout_width="match_parent" android:layout_height="wrap_content" android:max="120" android:progress="80" />
        </LinearLayout>
    </LinearLayout>
</ScrollView>
`;

const FIXED_MAIN_ACTIVITY_KT = `package com.audiomaster.pro

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Toast
import android.widget.ToggleButton
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var projectionManager: MediaProjectionManager
    private var mediaProjection: MediaProjection? = null
    private var youtubeAudioRecord: AudioRecord? = null
    @Volatile private var isCapturing = false
    private lateinit var youtubeWebView: WebView

    companion object {
        init { System.loadLibrary("audiomaster") }
        private const val REQUEST_CODE_CAPTURE = 1001
        private const val REQUEST_CODE_PERMISSIONS = 1002
    }

    external fun startAudioEngine()
    external fun stopAudioEngine()
    external fun setChannelGain(channelIndex: Int, gain: Float)
    external fun setDelayMix(mix: Float)
    external fun setHarmonyState(isActive: Boolean)
    external fun setHarmonyKey(keyIndex: Int)
    external fun setCompressorActive(isActive: Boolean)
    external fun setChannelEQ(channelIndex: Int, band: Int, gainDb: Float)
    external fun startWavRecording(filePath: String): Boolean
    external fun stopWavRecording()
    external fun pushYoutubeBuffer(buffer: FloatArray, size: Int)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupYoutubePlayer()
        setupAllControls()

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                REQUEST_CODE_PERMISSIONS
            )
        } else {
            initAudioSystem()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupYoutubePlayer() {
        youtubeWebView = findViewById(R.id.youtubeWebView)
        youtubeWebView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        youtubeWebView.webViewClient = WebViewClient()
        youtubeWebView.webChromeClient = WebChromeClient()
        loadYoutubeVideo("jfKfPfyJRdk")

        findViewById<Button>(R.id.btnLoadYt).setOnClickListener {
            val raw = findViewById<EditText>(R.id.editYoutubeUrl).text.toString().trim()
            val id = extractVideoId(raw) ?: raw
            loadYoutubeVideo(id)
        }
    }

    private fun loadYoutubeVideo(videoId: String) {
        val html = """
            <html><body style="margin:0;background:#000;">
            <iframe width="100%" height="100%"
              src="https://www.youtube.com/embed/$videoId?playsinline=1&autoplay=1"
              frameborder="0" allow="autoplay; encrypted-media" allowfullscreen>
            </iframe></body></html>
        """.trimIndent()
        youtubeWebView.loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "utf-8", null)
    }

    private fun extractVideoId(input: String): String? {
        val regex = Regex("(?:v=|youtu\\\\.be/|embed/)([a-zA-Z0-9_-]{11})")
        return regex.find(input)?.groupValues?.getOrNull(1)
    }

    private fun initAudioSystem() {
        startAudioEngine()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_CODE_CAPTURE)
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_CAPTURE && resultCode == Activity.RESULT_OK && data != null) {
            mediaProjection = projectionManager.getMediaProjection(resultCode, data)
            startYoutubeAudioCapture()
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun startYoutubeAudioCapture() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val nativeFrames = am.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER)?.toIntOrNull() ?: 256
        val readFloats = nativeFrames * 2

        val config = AudioPlaybackCaptureConfiguration.Builder(mediaProjection!!)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .build()

        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
            .setSampleRate(48000)
            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
            .build()

        val minBuf = AudioRecord.getMinBufferSize(48000, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_FLOAT)

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            youtubeAudioRecord = AudioRecord.Builder()
                .setAudioFormat(format)
                .setBufferSizeInBytes(maxOf(minBuf, readFloats * 4 * 4))
                .setAudioPlaybackCaptureConfig(config)
                .build()

            youtubeAudioRecord?.startRecording()
            isCapturing = true

            Thread {
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_AUDIO)
                val audioBuffer = FloatArray(readFloats)
                while (isCapturing) {
                    val readCount = youtubeAudioRecord?.read(audioBuffer, 0, audioBuffer.size, AudioRecord.READ_BLOCKING) ?: 0
                    if (readCount > 0) pushYoutubeBuffer(audioBuffer, readCount)
                }
            }.start()
        }
    }

    private fun setupAllControls() {
        findViewById<ToggleButton>(R.id.btnComp).setOnCheckedChangeListener { _, checked -> setCompressorActive(checked) }
        findViewById<ToggleButton>(R.id.btnHarmony).setOnCheckedChangeListener { _, checked -> setHarmonyState(checked) }

        val keys = arrayOf("Key: C", "Key: C#", "Key: D", "Key: D#", "Key: E", "Key: F", "Key: F#", "Key: G", "Key: G#", "Key: A", "Key: A#", "Key: B")
        val spinnerKey = findViewById<Spinner>(R.id.spinnerKey)
        spinnerKey.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, keys)
        spinnerKey.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = setHarmonyKey(pos)
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        findViewById<SeekBar>(R.id.seekDelay).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) setDelayMix(p / 100f) }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        var lastPath = ""
        findViewById<ToggleButton>(R.id.btnRecord).setOnCheckedChangeListener { btn, checked ->
            if (checked) {
                val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                val out = File(getExternalFilesDir(Environment.DIRECTORY_MUSIC), "AudioMaster_\$ts.wav")
                lastPath = out.absolutePath
                if (!startWavRecording(lastPath)) btn.isChecked = false
            } else {
                stopWavRecording()
                Toast.makeText(this, "WAV disimpan: \$lastPath", Toast.LENGTH_LONG).show()
            }
        }

        var selectedCh = 0
        val eqMem = Array(5) { intArrayOf(12, 12, 12) }
        val seekLow = findViewById<SeekBar>(R.id.seekEqLow)
        val seekMid = findViewById<SeekBar>(R.id.seekEqMid)
        val seekHigh = findViewById<SeekBar>(R.id.seekEqHigh)

        val spinnerEq = findViewById<Spinner>(R.id.spinnerEqChannel)
        spinnerEq.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, arrayOf("EQ: CH 1", "EQ: CH 2", "EQ: CH 3", "EQ: CH 4", "EQ: CH 5"))
        spinnerEq.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                selectedCh = pos
                seekLow.progress = eqMem[pos][0]
                seekMid.progress = eqMem[pos][1]
                seekHigh.progress = eqMem[pos][2]
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        fun bindEq(sb: SeekBar, band: Int) {
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        eqMem[selectedCh][band] = p
                        setChannelEQ(selectedCh, band, (p - 12).toFloat())
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        bindEq(seekLow, 0); bindEq(seekMid, 1); bindEq(seekHigh, 2)

        val faderIds = intArrayOf(R.id.faderCh1, R.id.faderCh2, R.id.faderCh3, R.id.faderCh4, R.id.faderYoutube)
        faderIds.forEachIndexed { idx, id ->
            findViewById<SeekBar>(id).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) setChannelGain(idx, p / 100f)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
    }

    override fun onDestroy() {
        isCapturing = false
        youtubeAudioRecord?.stop()
        youtubeAudioRecord?.release()
        stopAudioEngine()
        super.onDestroy()
    }
}
`;

const CMAKE_LISTS_TXT = `cmake_minimum_required(VERSION 3.22.1)
project("audiomaster")

find_package(oboe REQUIRED CONFIG)

add_library(audiomaster SHARED
    MixerEngine.cpp
)

target_link_libraries(audiomaster
    oboe::oboe
    android
    log
)
`;

const APP_BUILD_GRADLE_KTS = `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.audiomaster.pro"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.audiomaster.pro"
        minSdk = 29
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"

        externalNativeBuild {
            cmake {
                cppFlags("-std=c++17 -O3")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures { prefab = true }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("com.google.oboe:oboe:1.8.1")
}
`;

const COMPLETE_APK_WORKFLOW_YML = `name: Build AudioMaster Pro APK
on:
  workflow_dispatch:
  push:
    branches: [ main ]

jobs:
  build-apk:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'
      - uses: android-actions/setup-android@v3
      - name: Install Android NDK & CMake
        run: sdkmanager "ndk;26.1.10909125" "cmake;3.22.1" "platforms;android-34" "build-tools;34.0.0"
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.7'
      - name: Build Debug APK
        run: gradle assembleDebug --no-configuration-cache --stacktrace
      - name: Upload AudioMaster Pro APK
        uses: actions/upload-artifact@v4
        with:
          name: AudioMaster-Pro-debug.apk
          path: app/build/outputs/apk/debug/app-debug.apk
`;

export async function downloadAndroidApkProjectZip(): Promise<void> {
  const zip = new JSZip();
  zip.file('build.gradle.kts', ROOT_BUILD_GRADLE_KTS);
  zip.file('settings.gradle.kts', SETTINGS_GRADLE_KTS);
  zip.file('gradle.properties', GRADLE_PROPERTIES);
  zip.file('gradle/wrapper/gradle-wrapper.properties', GRADLE_WRAPPER_PROPERTIES);
  zip.file('app/build.gradle.kts', APP_BUILD_GRADLE_KTS);
  zip.file('app/src/main/AndroidManifest.xml', FIXED_ANDROID_MANIFEST_XML);
  zip.file('app/src/main/res/layout/activity_main.xml', ACTIVITY_MAIN_XML);
  zip.file('app/src/main/res/values/strings.xml', STRINGS_XML);
  zip.file('app/src/main/java/com/audiomaster/pro/MainActivity.kt', FIXED_MAIN_ACTIVITY_KT);
  zip.file('app/src/main/cpp/CMakeLists.txt', CMAKE_LISTS_TXT);
  zip.file('app/src/main/cpp/LockFreeRingBuffer.h', FIXED_LOCKFREE_RINGBUFFER_H);
  zip.file('app/src/main/cpp/MixerEngine.cpp', FIXED_MIXER_ENGINE_CPP);
  zip.file('.github/workflows/build-apk.yml', COMPLETE_APK_WORKFLOW_YML);
  zip.file(
    'README_APK.md',
    `# AudioMaster Pro — Native Android Studio & APK Project

Project ini sudah lengkap (root Gradle, settings.gradle.kts, activity_main.xml, C++ Oboe Lock-Free Ring Buffer, Kotlin MainActivity, dan GitHub Actions CI) untuk menghasilkan file \`.apk\`.

## Opsi 1: Build APK Otomatis di Cloud (Gratis, Tanpa Install Android Studio)
1. Ekstrak file ZIP ini dan upload ke repository GitHub baru.
2. Buka tab **Actions** -> pilih **Build AudioMaster Pro APK** -> klik **Run workflow**.
3. Setelah selesai (~2 menit), unduh artifact **AudioMaster-Pro-debug.apk** dan install di HP Android Anda.

## Opsi 2: Build Lokal via Android Studio
1. Buka folder hasil ekstrak di Android Studio.
2. Pilih menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
`
  );

  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'AudioMaster-Pro-Android-APK-Project.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
