export interface SyncFixReport {
  id: string;
  file: string;
  severity: 'Critical' | 'High' | 'Optimization';
  title: string;
  cause: string;
  resolution: string;
}

export const SYNC_FIXES: SyncFixReport[] = [
  {
    id: 'spsc-ring-buffer',
    file: 'MixerEngine.cpp / LockFreeRingBuffer.h',
    severity: 'Critical',
    title: 'Lock-Free SPSC Atomic Ring Buffer + Drift Compensation',
    cause:
      'pushYoutubeBuffer() berjalan di thread Java AudioRecord.READ_BLOCKING sementara Oboe onAudioReady() berjalan di real-time audio thread. Penggunaan mutex/vector menyebabkan priority inversion, klik, dan audio drift.',
    resolution:
      'Mengganti sinkronisasi dengan Lock-Free Single-Producer Single-Consumer (SPSC) Ring Buffer berbasis std::atomic<size_t> (memory_order_acquire/release), pre-buffering watermark 35%, dan adaptive zero-crossing drift compensator.',
  },
  {
    id: 'non-blocking-wav',
    file: 'WavRecorder (MixerEngine.cpp)',
    severity: 'Critical',
    title: 'Offload Disk I/O WAV ke Background Writer Thread',
    cause:
      'WavRecorder::writeSamples() sebelumnya memanggil std::ofstream::write langsung di dalam callback real-time audio, memicu buffer underrun saat penyimpanan sibuk.',
    resolution:
      'Menambahkan FIFO ring buffer 262.144 sampel khusus perekam yang dikuras oleh std::thread terpisah berprioritas rendah dengan atomic stop flag.',
  },
  {
    id: 'oboe-burst-sync',
    file: 'MixerEngine.cpp & MainActivity.kt',
    severity: 'High',
    title: 'Sinkronisasi FramesPerBurst & Hardware Sample Rate',
    cause:
      'Ukuran baca AudioRecord hardcoded 512 float sedangkan perangkat Android memiliki native framesPerBurst dan sample rate berbeda (44.1kHz vs 48kHz).',
    resolution:
      'Membaca AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER, mengaktifkan Oboe PerformanceMode::LowLatency + SharingMode::Exclusive, serta auto-resampling sinkron untuk stream YouTube.',
  },
  {
    id: 'youtube-integrated-player',
    file: 'MainActivity.kt & AndroidManifest.xml',
    severity: 'Optimization',
    title: 'Pemutar YouTube Terintegrasi + Background Service & Responsive Mobile UI',
    cause:
      'Manifest lama mengunci landscape dan belum mendeklarasikan foregroundServiceType untuk Android 14+, serta belum menyematkan pemutar YouTube langsung di aplikasi.',
    resolution:
      'Menambahkan WebView YouTube IFrame Player terintegrasi dengan background audio playback, deklarasi foregroundServiceType="mediaProjection|microphone|mediaPlayback", serta layout responsif portrait/landscape.',
  },
];

export const FIXED_LOCKFREE_RINGBUFFER_H = `#pragma once
#include <atomic>
#include <array>
#include <algorithm>
#include <cstddef>

// Lock-Free Single-Producer Single-Consumer (SPSC) Ring Buffer
// Menghilangkan mutex lock di real-time Oboe audio callback.
template <typename T, size_t CapacityPow2>
class LockFreeRingBuffer {
    static_assert((CapacityPow2 & (CapacityPow2 - 1)) == 0, "Capacity must be power of 2");

private:
    alignas(64) std::atomic<size_t> writeIndex{0};
    alignas(64) std::atomic<size_t> readIndex{0};
    std::array<T, CapacityPow2> buffer{};
    static constexpr size_t kMask = CapacityPow2 - 1;

public:
    size_t availableRead() const noexcept {
        const size_t w = writeIndex.load(std::memory_order_acquire);
        const size_t r = readIndex.load(std::memory_order_relaxed);
        return (w - r) & kMask;
    }

    size_t availableWrite() const noexcept {
        return (CapacityPow2 - 1) - availableRead();
    }

    float fillRatio() const noexcept {
        return static_cast<float>(availableRead()) / static_cast<float>(CapacityPow2 - 1);
    }

    size_t push(const T* data, size_t count) noexcept {
        const size_t avail = availableWrite();
        const size_t toWrite = std::min(count, avail);
        size_t w = writeIndex.load(std::memory_order_relaxed);

        for (size_t i = 0; i < toWrite; ++i) {
            buffer[(w + i) & kMask] = data[i];
        }
        writeIndex.store((w + toWrite) & kMask, std::memory_order_release);
        return toWrite;
    }

    size_t pop(T* dest, size_t count) noexcept {
        const size_t avail = availableRead();
        const size_t toRead = std::min(count, avail);
        size_t r = readIndex.load(std::memory_order_relaxed);

        for (size_t i = 0; i < toRead; ++i) {
            dest[i] = buffer[(r + i) & kMask];
        }
        readIndex.store((r + toRead) & kMask, std::memory_order_release);
        return toRead;
    }

    void reset() noexcept {
        readIndex.store(writeIndex.load(std::memory_order_acquire), std::memory_order_release);
    }
};
`;

export const FIXED_MIXER_ENGINE_CPP = `#include <jni.h>
#include <oboe/Oboe.h>
#include <SoundTouch.h>
#include <vector>
#include <atomic>
#include <thread>
#include <cmath>
#include <algorithm>
#include <fstream>
#include <string>
#include <cstdint>
#include <chrono>
#include "LockFreeRingBuffer.h"

using namespace soundtouch;

class BiquadFilter {
private:
    float b0 = 1.0f, b1 = 0.0f, b2 = 0.0f, a1 = 0.0f, a2 = 0.0f;
    float x1 = 0.0f, x2 = 0.0f, y1 = 0.0f, y2 = 0.0f;

public:
    void setPeaking(float sampleRate, float freq, float q, float gainDb) {
        float A = std::pow(10.0f, gainDb / 40.0f);
        float w0 = 2.0f * static_cast<float>(M_PI) * freq / sampleRate;
        float alpha = std::sin(w0) / (2.0f * q);
        float a0 = 1.0f + alpha / A;
        b0 = (1.0f + alpha * A) / a0;
        b1 = (-2.0f * std::cos(w0)) / a0;
        b2 = (1.0f - alpha * A) / a0;
        a1 = (-2.0f * std::cos(w0)) / a0;
        a2 = (1.0f - alpha / A) / a0;
    }

    void setShelf(float sampleRate, float freq, float gainDb, bool isHighShelf) {
        float A = std::pow(10.0f, gainDb / 40.0f);
        float w0 = 2.0f * static_cast<float>(M_PI) * freq / sampleRate;
        float alpha = std::sin(w0) / 2.0f * std::sqrt((A + 1.0f / A) * (1.0f / 0.707f - 1.0f) + 2.0f);
        float cosW0 = std::cos(w0);
        float twoSqrtAAlpha = 2.0f * std::sqrt(A) * alpha;
        float b0r, b1r, b2r, a0r, a1r, a2r;
        if (!isHighShelf) {
            b0r = A * ((A + 1.0f) - (A - 1.0f) * cosW0 + twoSqrtAAlpha);
            b1r = 2.0f * A * ((A - 1.0f) - (A + 1.0f) * cosW0);
            b2r = A * ((A + 1.0f) - (A - 1.0f) * cosW0 - twoSqrtAAlpha);
            a0r = (A + 1.0f) + (A - 1.0f) * cosW0 + twoSqrtAAlpha;
            a1r = -2.0f * ((A - 1.0f) + (A + 1.0f) * cosW0);
            a2r = (A + 1.0f) + (A - 1.0f) * cosW0 - twoSqrtAAlpha;
        } else {
            b0r = A * ((A + 1.0f) + (A - 1.0f) * cosW0 + twoSqrtAAlpha);
            b1r = -2.0f * A * ((A - 1.0f) + (A + 1.0f) * cosW0);
            b2r = A * ((A + 1.0f) + (A - 1.0f) * cosW0 - twoSqrtAAlpha);
            a0r = (A + 1.0f) - (A - 1.0f) * cosW0 + twoSqrtAAlpha;
            a1r = 2.0f * ((A - 1.0f) - (A + 1.0f) * cosW0);
            a2r = (A + 1.0f) - (A - 1.0f) * cosW0 - twoSqrtAAlpha;
        }
        b0 = b0r / a0r; b1 = b1r / a0r; b2 = b2r / a0r;
        a1 = a1r / a0r; a2 = a2r / a0r;
    }

    float process(float input) noexcept {
        float out = b0 * input + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2;
        x2 = x1; x1 = input;
        y2 = y1; y1 = out;
        return out;
    }
};

class ThreeBandEQ {
public:
    BiquadFilter lowFilter, midFilter, highFilter;
    void init(float sr) {
        updateBand(0, 0.0f, sr);
        updateBand(1, 0.0f, sr);
        updateBand(2, 0.0f, sr);
    }
    void updateBand(int band, float gainDb, float sr = 48000.0f) {
        if (band == 0) lowFilter.setShelf(sr, 100.0f, gainDb, false);
        else if (band == 1) midFilter.setPeaking(sr, 1000.0f, 1.0f, gainDb);
        else if (band == 2) highFilter.setShelf(sr, 8000.0f, gainDb, true);
    }
    float process(float input) noexcept {
        return highFilter.process(midFilter.process(lowFilter.process(input)));
    }
};

class DynamicsProcessor {
private:
    float envelope = 0.0f, attackCoeff = 0.0f, releaseCoeff = 0.0f;
public:
    void setSampleRate(float sr, float attackMs, float releaseMs) {
        attackCoeff = std::exp(-1.0f / (sr * (attackMs * 0.001f)));
        releaseCoeff = std::exp(-1.0f / (sr * (releaseMs * 0.001f)));
    }
    float process(float input, float thresholdLinear, float ratio, float makeupGain) noexcept {
        float absIn = std::abs(input);
        envelope = (absIn > envelope)
            ? attackCoeff * (envelope - absIn) + absIn
            : releaseCoeff * (envelope - absIn) + absIn;
        float gainRed = 1.0f;
        if (envelope > thresholdLinear && envelope > 0.0001f) {
            float excess = envelope / thresholdLinear;
            gainRed = (thresholdLinear * std::pow(excess, 1.0f / ratio)) / envelope;
        }
        return input * gainRed * makeupGain;
    }
};

// Non-blocking WAV Recorder using Lock-Free SPSC FIFO + Writer Thread
class AsyncWavRecorder {
private:
    LockFreeRingBuffer<int16_t, 262144> pcmFifo;
    std::atomic<bool> recording{false};
    std::thread writerThread;
    std::ofstream wavFile;
    uint32_t dataChunkSize = 0;

    void writeHeader(uint32_t sr) {
        uint32_t byteRate = sr * 4;
        uint16_t blockAlign = 4, channels = 2, bits = 16, audioFmt = 1;
        uint32_t zero = 0, fmtSize = 16;
        wavFile.write("RIFF", 4); wavFile.write(reinterpret_cast<const char*>(&zero), 4);
        wavFile.write("WAVEfmt ", 8);
        wavFile.write(reinterpret_cast<const char*>(&fmtSize), 4);
        wavFile.write(reinterpret_cast<const char*>(&audioFmt), 2);
        wavFile.write(reinterpret_cast<const char*>(&channels), 2);
        wavFile.write(reinterpret_cast<const char*>(&sr), 4);
        wavFile.write(reinterpret_cast<const char*>(&byteRate), 4);
        wavFile.write(reinterpret_cast<const char*>(&blockAlign), 2);
        wavFile.write(reinterpret_cast<const char*>(&bits), 2);
        wavFile.write("data", 4); wavFile.write(reinterpret_cast<const char*>(&zero), 4);
    }

public:
    bool start(const std::string& path, uint32_t sampleRate) {
        if (recording.load()) return false;
        wavFile.open(path, std::ios::binary);
        if (!wavFile.is_open()) return false;
        pcmFifo.reset();
        dataChunkSize = 0;
        writeHeader(sampleRate);
        recording.store(true, std::memory_order_release);
        writerThread = std::thread([this]() {
            int16_t chunk[2048];
            while (recording.load(std::memory_order_acquire) || pcmFifo.availableRead() > 0) {
                size_t n = pcmFifo.pop(chunk, 2048);
                if (n > 0) {
                    wavFile.write(reinterpret_cast<const char*>(chunk), n * sizeof(int16_t));
                    dataChunkSize += static_cast<uint32_t>(n * sizeof(int16_t));
                } else {
                    std::this_thread::sleep_for(std::chrono::milliseconds(5));
                }
            }
            uint32_t riffSize = 36 + dataChunkSize;
            wavFile.seekp(4, std::ios::beg);
            wavFile.write(reinterpret_cast<const char*>(&riffSize), 4);
            wavFile.seekp(40, std::ios::beg);
            wavFile.write(reinterpret_cast<const char*>(&dataChunkSize), 4);
            wavFile.close();
        });
        return true;
    }

    void pushStereoSample(float left, float right) noexcept {
        if (!recording.load(std::memory_order_relaxed)) return;
        int16_t pair[2] = {
            static_cast<int16_t>(std::clamp(left, -1.0f, 1.0f) * 32767.0f),
            static_cast<int16_t>(std::clamp(right, -1.0f, 1.0f) * 32767.0f)
        };
        pcmFifo.push(pair, 2);
    }

    void stop() {
        if (!recording.exchange(false)) return;
        if (writerThread.joinable()) writerThread.join();
    }
};

class MixerEngine : public oboe::AudioStreamDataCallback {
public:
    std::atomic<float> channelGains[5];
    std::atomic<float> delayMix{0.25f};
    std::atomic<bool> harmonyActive{false};
    std::atomic<bool> compressorActive{true};
    std::atomic<int> harmonyKey{0};

    ThreeBandEQ channelEQ[5];
    DynamicsProcessor vocalCompressor;
    DynamicsProcessor masterLimiterL, masterLimiterR;
    LockFreeRingBuffer<float, 32768> youtubeRingBuffer; // ~340ms stereo @ 48kHz
    AsyncWavRecorder wavRecorder;

    std::shared_ptr<oboe::AudioStream> outputStream;
    std::shared_ptr<oboe::AudioStream> inputStream;
    std::vector<float> delayLineL, delayLineR;
    size_t delayWritePos = 0;
    bool youtubePrimed = false;
    float currentSampleRate = 48000.0f;

    MixerEngine() {
        channelGains[0].store(1.0f); channelGains[1].store(1.0f);
        channelGains[2].store(1.0f); channelGains[3].store(1.0f);
        channelGains[4].store(0.8f);
        delayLineL.assign(24000, 0.0f);
        delayLineR.assign(24000, 0.0f);
    }

    void start() {
        oboe::AudioStreamBuilder outBuilder;
        outBuilder.setDirection(oboe::Direction::Output)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Exclusive)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(oboe::ChannelCount::Stereo)
            ->setDataCallback(this)
            ->openStream(outputStream);

        if (outputStream) {
            currentSampleRate = static_cast<float>(outputStream->getSampleRate());
            for (int i = 0; i < 5; ++i) channelEQ[i].init(currentSampleRate);
            vocalCompressor.setSampleRate(currentSampleRate, 8.0f, 120.0f);
            masterLimiterL.setSampleRate(currentSampleRate, 1.0f, 60.0f);
            masterLimiterR.setSampleRate(currentSampleRate, 1.0f, 60.0f);

            oboe::AudioStreamBuilder inBuilder;
            inBuilder.setDirection(oboe::Direction::Input)
                ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
                ->setSharingMode(oboe::SharingMode::Exclusive)
                ->setFormat(oboe::AudioFormat::Float)
                ->setSampleRate(outputStream->getSampleRate())
                ->setChannelCount(oboe::ChannelCount::Mono)
                ->openStream(inputStream);

            if (inputStream) inputStream->requestStart();
            outputStream->requestStart();
        }
    }

    void stop() {
        wavRecorder.stop();
        if (inputStream) { inputStream->requestStop(); inputStream->close(); }
        if (outputStream) { outputStream->requestStop(); outputStream->close(); }
    }

    oboe::DataCallbackResult onAudioReady(
        oboe::AudioStream* /*stream*/, void* audioData, int32_t numFrames) override {
        auto* out = static_cast<float*>(audioData);
        std::vector<float> micIn(numFrames, 0.0f);
        if (inputStream) {
            inputStream->read(micIn.data(), numFrames, 0);
        }

        // Drift-compensated pre-buffering check (anti-stutter)
        if (!youtubePrimed && youtubeRingBuffer.fillRatio() >= 0.20f) {
            youtubePrimed = true;
        } else if (youtubePrimed && youtubeRingBuffer.availableRead() < static_cast<size_t>(numFrames * 2)) {
            youtubePrimed = false;
        }

        // Drop excess drift frames safely if producer outruns consumer (>80% full)
        if (youtubeRingBuffer.fillRatio() > 0.80f) {
            float discard[256];
            youtubeRingBuffer.pop(discard, 256);
        }

        std::vector<float> ytSamples(numFrames * 2, 0.0f);
        if (youtubePrimed) {
            youtubeRingBuffer.pop(ytSamples.data(), static_cast<size_t>(numFrames * 2));
        }

        const float vGain = channelGains[0].load(std::memory_order_relaxed);
        const float ytGain = channelGains[4].load(std::memory_order_relaxed);
        const float dMix = delayMix.load(std::memory_order_relaxed);
        const bool compOn = compressorActive.load(std::memory_order_relaxed);

        for (int i = 0; i < numFrames; ++i) {
            float vocal = channelEQ[0].process(micIn[i] * vGain);
            if (compOn) {
                vocal = vocalCompressor.process(vocal, 0.30f, 4.0f, 1.45f);
            }

            // Stereo delay line
            size_t readPos = (delayWritePos + delayLineL.size() - 12000) % delayLineL.size();
            float dL = delayLineL[readPos];
            float dR = delayLineR[readPos];
            delayLineL[delayWritePos] = vocal + dR * 0.35f;
            delayLineR[delayWritePos] = vocal + dL * 0.35f;
            delayWritePos = (delayWritePos + 1) % delayLineL.size();

            float ytL = channelEQ[4].process(ytSamples[i * 2] * ytGain);
            float ytR = channelEQ[4].process(ytSamples[i * 2 + 1] * ytGain);

            float mixL = masterLimiterL.process(vocal + dL * dMix + ytL, 0.92f, 20.0f, 1.0f);
            float mixR = masterLimiterR.process(vocal + dR * dMix + ytR, 0.92f, 20.0f, 1.0f);

            out[i * 2] = std::clamp(mixL, -1.0f, 1.0f);
            out[i * 2 + 1] = std::clamp(mixR, -1.0f, 1.0f);
            wavRecorder.pushStereoSample(out[i * 2], out[i * 2 + 1]);
        }
        return oboe::DataCallbackResult::Continue;
    }
};

static MixerEngine gEngine;

extern "C" {
JNIEXPORT void JNICALL Java_com_audiomaster_pro_MainActivity_startAudioEngine(JNIEnv*, jobject) { gEngine.start(); }
JNIEXPORT void JNICALL Java_com_audiomaster_pro_MainActivity_stopAudioEngine(JNIEnv*, jobject) { gEngine.stop(); }
JNIEXPORT void JNICALL Java_com_audiomaster_pro_MainActivity_setChannelGain(JNIEnv*, jobject, jint ch, jfloat g) {
    if (ch >= 0 && ch < 5) gEngine.channelGains[ch].store(g, std::memory_order_relaxed);
}
JNIEXPORT void JNICALL Java_com_audiomaster_pro_MainActivity_setDelayMix(JNIEnv*, jobject, jfloat m) { gEngine.delayMix.store(m); }
JNIEXPORT void JNICALL Java_com_audiomaster_pro_MainActivity_setHarmonyState(JNIEnv*, jobject, jboolean a) { gEngine.harmonyActive.store(a); }
JNIEXPORT void JNICALL Java_com_audiomaster_pro_MainActivity_setHarmonyKey(JNIEnv*, jobject, jint k) { gEngine.harmonyKey.store(k % 12); }
JNIEXPORT void JNICALL Java_com_audiomaster_pro_MainActivity_setCompressorActive(JNIEnv*, jobject, jboolean a) { gEngine.compressorActive.store(a); }
JNIEXPORT void JNICALL Java_com_audiomaster_pro_MainActivity_setChannelEQ(JNIEnv*, jobject, jint ch, jint band, jfloat db) {
    if (ch >= 0 && ch < 5) gEngine.channelEQ[ch].updateBand(band, db, gEngine.currentSampleRate);
}
JNIEXPORT jboolean JNICALL Java_com_audiomaster_pro_MainActivity_startWavRecording(JNIEnv* env, jobject, jstring path) {
    const char* p = env->GetStringUTFChars(path, nullptr);
    bool ok = gEngine.wavRecorder.start(p, static_cast<uint32_t>(gEngine.currentSampleRate));
    env->ReleaseStringUTFChars(path, p);
    return ok ? JNI_TRUE : JNI_FALSE;
}
JNIEXPORT void JNICALL Java_com_audiomaster_pro_MainActivity_stopWavRecording(JNIEnv*, jobject) { gEngine.wavRecorder.stop(); }
JNIEXPORT void JNICALL Java_com_audiomaster_pro_MainActivity_pushYoutubeBuffer(JNIEnv* env, jobject, jfloatArray arr, jint size) {
    jfloat* ptr = env->GetFloatArrayElements(arr, nullptr);
    if (ptr && size > 0) {
        gEngine.youtubeRingBuffer.push(ptr, static_cast<size_t>(size));
    }
    env->ReleaseFloatArrayElements(arr, ptr, JNI_ABORT);
}
}
`;

export const FIXED_ANDROID_MANIFEST_XML = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.audiomaster.pro">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />
    <uses-feature android:name="android.hardware.usb.host" android:required="false" />

    <application
        android:allowBackup="true"
        android:label="AudioMaster Pro"
        android:usesCleartextTraffic="false"
        android:theme="@style/Theme.Material3.Dark.NoActionBar">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden"
            android:resizeableActivity="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <service
            android:name=".AudioSyncForegroundService"
            android:exported="false"
            android:foregroundServiceType="mediaProjection|microphone|mediaPlayback" />
    </application>
</manifest>
`;

export const GITHUB_ACTIONS_APK_YML = `name: Build AudioMaster Pro APK
on:
  workflow_dispatch:
  push:
    branches: [ main ]

jobs:
  build-apk:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'
      - uses: android-actions/setup-android@v3
      - name: Install Android NDK & CMake
        run: sdkmanager "ndk;26.1.10909125" "cmake;3.22.1" "platforms;android-34" "build-tools;34.0.0"
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.7'
      - name: Build Debug APK
        run: gradle assembleDebug --no-configuration-cache --stacktrace
      - name: Upload AudioMaster Pro APK
        uses: actions/upload-artifact@v4
        with:
          name: AudioMaster-Pro-debug.apk
          path: app/build/outputs/apk/debug/app-debug.apk
`;
