import { useEffect, useRef, useState } from 'react';
import {
  Sliders,
  Youtube,
  Sparkles,
  Smartphone,
  Download,
  WifiOff,
  CheckCircle2,
} from 'lucide-react';
import {
  AudioDspEngine,
  CompressorParams,
  EqBands,
  HarmonyParams,
  MasteringTelemetry,
} from './audio/AudioDspEngine';
import { YouTubePlayerDeck, YouTubeTrackInfo } from './components/YouTubePlayerDeck';
import { MixerConsole } from './components/MixerConsole';
import {
  AiMasteringPanel,
  AiMasteringPreset,
  AiVocalDiagnosis,
} from './components/AiMasteringPanel';
import { SyncAndApkPanel } from './components/SyncAndApkPanel';
import { VoiceCommandBar } from './components/VoiceCommandBar';
import { VoiceDspAction } from './audio/voiceCommandParser';
import { useOnlineStatus, usePWAInstall } from './hooks/usePWAInstall';
import { useVoiceCommands } from './hooks/useVoiceCommands';
import { downloadAndroidApkProjectZip } from './native/apkZipBuilder';

type AppTab = 'mixer' | 'youtube' | 'ai' | 'apk';

const INITIAL_TELEMETRY: MasteringTelemetry = {
  isRunning: false,
  micActive: false,
  testVocalActive: false,
  backingActive: false,
  systemAudioActive: false,
  isRecording: false,
  recordingDurationSec: 0,
  sampleRate: 48000,
  latencyMs: 0,
  syncOffsetMs: 0,
  syncDriftMs: 0.2,
  bufferFillPct: 50,
  vocalRmsDb: -60,
  vocalPeakDb: -60,
  masterRmsDb: -60,
  masterPeakDb: -60,
  gainReductionDb: 0,
  detectedPitchHz: 0,
  detectedNote: '--',
  activeHarmonyInterval: 4,
  channelLevels: [0, 0, 0, 0, 0],
  spectrumBins: new Array(24).fill(0),
};

export default function App() {
  const engineRef = useRef<AudioDspEngine | null>(null);
  if (!engineRef.current) {
    engineRef.current = new AudioDspEngine();
  }

  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const isOnline = useOnlineStatus();

  const [activeTab, setActiveTab] = useState<AppTab>('mixer');
  const [telemetry, setTelemetry] = useState<MasteringTelemetry>(INITIAL_TELEMETRY);
  const [youtubePlaying, setYoutubePlaying] = useState(false);
  const [activeTrack, setActiveTrack] = useState<YouTubeTrackInfo>({
    videoId: 'jfKfPfyJRdk',
    title: 'Lofi Hip Hop Radio — Smooth Backing Groove',
    author: 'Lofi Girl',
  });

  // Mixer State
  const [channelGains, setChannelGains] = useState<[number, number, number, number, number]>([
    1.0, 0.85, 0.9, 0.85, 0.8,
  ]);
  const [channelMuted, setChannelMuted] = useState<[boolean, boolean, boolean, boolean, boolean]>([
    false, false, false, false, false,
  ]);
  const [selectedEqChannel, setSelectedEqChannel] = useState(0);
  const [channelEqs, setChannelEqs] = useState<EqBands[]>(() =>
    Array.from({ length: 5 }, () => ({ low: 0, mid: 0, high: 0 }))
  );
  const [compressor, setCompressor] = useState<CompressorParams>({
    enabled: true,
    thresholdDb: -18,
    ratio: 4,
    attackMs: 8,
    releaseMs: 120,
    makeupDb: 3.5,
  });
  const [harmony, setHarmony] = useState<HarmonyParams>({
    enabled: false,
    keyIndex: 0,
    mode: 'smart_3rd',
    mix: 0.45,
  });
  const [delayMix, setDelayMix] = useState(0.25);
  const [delayTimeMs, setDelayTimeMs] = useState(240);
  const [autoMasterEnabled, setAutoMasterEnabled] = useState(true);
  const [recordedWavUrl, setRecordedWavUrl] = useState<string | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // AI State
  const [externalAiPreset, setExternalAiPreset] = useState<AiMasteringPreset | null>(null);
  const [isGeneratingFromYt, setIsGeneratingFromYt] = useState(false);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    window.setTimeout(() => {
      setToastMsg((prev) => (prev === msg ? null : prev));
    }, 3500);
  };

  // Telemetry polling loop (12 FPS for crisp metering without main-thread overhead)
  useEffect(() => {
    const id = window.setInterval(() => {
      if (engineRef.current) {
        setTelemetry(engineRef.current.getTelemetry(youtubePlaying));
      }
    }, 85);
    return () => window.clearInterval(id);
  }, [youtubePlaying]);

  const handleChannelGain = (ch: number, gain: number) => {
    setChannelGains((prev) => {
      const next = [...prev] as [number, number, number, number, number];
      next[ch] = gain;
      return next;
    });
    engineRef.current?.setChannelGain(ch, gain);
  };

  const handleToggleMute = (ch: number) => {
    setChannelMuted((prev) => {
      const next = [...prev] as [boolean, boolean, boolean, boolean, boolean];
      next[ch] = !next[ch];
      engineRef.current?.setChannelMute(ch, next[ch]);
      return next;
    });
  };

  const handleChangeEq = (ch: number, band: 'low' | 'mid' | 'high', db: number) => {
    setChannelEqs((prev) => {
      const next = prev.map((eq, i) => (i === ch ? { ...eq, [band]: db } : eq));
      return next;
    });
    engineRef.current?.setChannelEq(ch, band, db);
  };

  const handleResetEq = (ch: number) => {
    setChannelEqs((prev) => prev.map((eq, i) => (i === ch ? { low: 0, mid: 0, high: 0 } : eq)));
    engineRef.current?.setChannelEq(ch, 'low', 0);
    engineRef.current?.setChannelEq(ch, 'mid', 0);
    engineRef.current?.setChannelEq(ch, 'high', 0);
  };

  const handleChangeCompressor = (partial: Partial<CompressorParams>) => {
    setCompressor((prev) => ({ ...prev, ...partial }));
    engineRef.current?.setCompressor(partial);
  };

  const handleChangeHarmony = (partial: Partial<HarmonyParams>) => {
    setHarmony((prev) => ({ ...prev, ...partial }));
    engineRef.current?.setHarmony(partial);
  };

  const handleChangeDelay = (mix: number, timeMs?: number) => {
    setDelayMix(mix);
    if (typeof timeMs === 'number') setDelayTimeMs(timeMs);
    engineRef.current?.setDelay(mix, timeMs);
  };

  const handleToggleAutoMaster = () => {
    const next = !autoMasterEnabled;
    setAutoMasterEnabled(next);
    engineRef.current?.setAutoMaster(next);
  };

  const handleToggleMic = async () => {
    try {
      const active = await engineRef.current?.toggleMicrophone();
      showToast(active ? 'Mikrofon terhubung ke CH 1 DSP' : 'Mikrofon dimatikan');
    } catch {
      showToast('Izin mikrofon ditolak atau perangkat tidak tersedia.');
    }
  };

  const handleToggleTestVocal = () => {
    const active = engineRef.current?.toggleTestVocal();
    showToast(active ? 'Vocal Synth Uji DSP aktif di CH 1' : 'Vocal Synth dimatikan');
  };

  const handleToggleBacking = () => {
    const active = engineRef.current?.toggleStudioBacking();
    showToast(active ? 'Loop musik latar aktif di CH 3 & CH 4' : 'Loop musik dimatikan');
  };

  const handleToggleSystemAudio = async () => {
    try {
      const active = await engineRef.current?.toggleSystemAudioCapture();
      showToast(active ? 'Audio YouTube/Tab terhubung ke CH 5 DSP!' : 'Capture audio tab dihentikan');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Gagal menangkap audio sistem.');
    }
  };

  const handleToggleRecord = () => {
    if (!engineRef.current) return;
    if (telemetry.isRecording) {
      const blob = engineRef.current.stopRecordingAndBuildWav();
      if (blob) {
        if (recordedWavUrl) URL.revokeObjectURL(recordedWavUrl);
        setRecordedWavUrl(URL.createObjectURL(blob));
        showToast('Rekaman Stereo .WAV selesai dan siap diunduh!');
      }
    } else {
      engineRef.current.startRecording();
      showToast('Merekam Master Mix ke 48kHz Stereo WAV...');
    }
  };

  const handleUploadBacking = (deck: 0 | 1, file: File) => {
    engineRef.current?.loadLocalBackingFile(deck, file);
    showToast(`Memutar "${file.name}" di CH ${deck === 0 ? 3 : 4}`);
  };

  const applyAiPresetToDsp = (preset: AiMasteringPreset) => {
    void engineRef.current?.startEngine();
    handleChangeCompressor({
      enabled: true,
      thresholdDb: preset.compressor.thresholdDb,
      ratio: preset.compressor.ratio,
      attackMs: preset.compressor.attackMs,
      releaseMs: preset.compressor.releaseMs,
      makeupDb: preset.compressor.makeupDb,
    });
    handleChangeHarmony({
      enabled: true,
      keyIndex: Math.max(0, Math.min(11, preset.detectedKeyIndex)),
      mode: preset.harmonyInterval || 'smart_3rd',
      mix: preset.harmonyMix,
    });
    handleChangeEq(0, 'low', preset.vocalEq.lowDb);
    handleChangeEq(0, 'mid', preset.vocalEq.midDb);
    handleChangeEq(0, 'high', preset.vocalEq.highDb);
    handleChangeEq(4, 'low', preset.youtubeEq.lowDb);
    handleChangeEq(4, 'mid', preset.youtubeEq.midDb);
    handleChangeEq(4, 'high', preset.youtubeEq.highDb);
    handleChangeDelay(preset.delayMix, preset.delayTimeMs);
    engineRef.current?.setAutoDuckAmount(preset.autoDuckAmount);
    setAutoMasterEnabled(true);
    engineRef.current?.setAutoMaster(true);
  };

  const applyAiDiagnosis = (diag: AiVocalDiagnosis) => {
    handleChangeCompressor({
      enabled: true,
      thresholdDb: diag.suggestedThresholdDb,
    });
    handleChangeEq(0, 'high', diag.suggestedHighBoostDb);
    handleChangeEq(0, 'mid', diag.suggestedMidCutDb);
    engineRef.current?.setSyncOffsetMs(diag.suggestedSyncOffsetMs);
  };

  const handleAiAutoMasterFromTrack = async (track: YouTubeTrackInfo) => {
    setIsGeneratingFromYt(true);
    setActiveTab('ai');
    try {
      const res = await fetch('/api/ai/mastering-preset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          songTitle: track.title,
          genre: 'Pop Karaoke',
          vocalStyle: 'Balanced Studio',
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || 'Gagal menjalankan AI Auto-Master.');
        return;
      }
      const preset = data as AiMasteringPreset;
      setExternalAiPreset(preset);
      applyAiPresetToDsp(preset);
      showToast(`AI Auto-Master diterapkan untuk "${track.title}"`);
    } catch {
      showToast('Gagal terhubung ke server AI.');
    } finally {
      setIsGeneratingFromYt(false);
    }
  };

  const handlePrimaryHeaderAction = async () => {
    if (isInstallable) {
      await install();
    } else {
      await downloadAndroidApkProjectZip();
      showToast('Mengunduh AudioMaster-Pro-Android-APK-Project.zip');
    }
  };

  const handleExecuteVoiceAction = (action: VoiceDspAction) => {
    void engineRef.current?.startEngine();

    if (
      typeof action.compressorEnabled === 'boolean' ||
      typeof action.compressorThresholdDeltaDb === 'number' ||
      typeof action.compressorRatioDelta === 'number' ||
      typeof action.compressorMakeupDeltaDb === 'number'
    ) {
      const nextThreshold = Math.max(
        -40,
        Math.min(0, compressor.thresholdDb + (action.compressorThresholdDeltaDb ?? 0))
      );
      const nextRatio = Math.max(
        1,
        Math.min(12, compressor.ratio + (action.compressorRatioDelta ?? 0))
      );
      const nextMakeup = Math.max(
        0,
        Math.min(12, compressor.makeupDb + (action.compressorMakeupDeltaDb ?? 0))
      );
      handleChangeCompressor({
        enabled: action.compressorEnabled ?? compressor.enabled,
        thresholdDb: nextThreshold,
        ratio: nextRatio,
        makeupDb: nextMakeup,
      });
    }

    if (
      typeof action.harmonyEnabled === 'boolean' ||
      action.harmonyMode ||
      typeof action.harmonyKeyIndex === 'number' ||
      typeof action.harmonyMixDelta === 'number'
    ) {
      const nextMix = Math.max(
        0,
        Math.min(1, Number((harmony.mix + (action.harmonyMixDelta ?? 0)).toFixed(2)))
      );
      handleChangeHarmony({
        enabled: action.harmonyEnabled ?? harmony.enabled,
        mode: action.harmonyMode ?? harmony.mode,
        keyIndex:
          typeof action.harmonyKeyIndex === 'number'
            ? Math.max(0, Math.min(11, action.harmonyKeyIndex))
            : harmony.keyIndex,
        mix: nextMix,
      });
    }

    if (typeof action.delayMixAbsolute === 'number') {
      handleChangeDelay(Math.max(0, Math.min(0.8, action.delayMixAbsolute)));
    } else if (typeof action.delayMixDelta === 'number') {
      handleChangeDelay(
        Math.max(0, Math.min(0.8, Number((delayMix + action.delayMixDelta).toFixed(2))))
      );
    }

    if (action.resetVocalEq) {
      handleResetEq(0);
    } else {
      const currentVocalEq = channelEqs[0];
      if (typeof action.vocalEqLowDelta === 'number') {
        handleChangeEq(0, 'low', Math.max(-12, Math.min(12, currentVocalEq.low + action.vocalEqLowDelta)));
      }
      if (typeof action.vocalEqMidDelta === 'number') {
        handleChangeEq(0, 'mid', Math.max(-12, Math.min(12, currentVocalEq.mid + action.vocalEqMidDelta)));
      }
      if (typeof action.vocalEqHighDelta === 'number') {
        handleChangeEq(0, 'high', Math.max(-12, Math.min(12, currentVocalEq.high + action.vocalEqHighDelta)));
      }
    }

    if (typeof action.autoMasterEnabled === 'boolean' && action.autoMasterEnabled !== autoMasterEnabled) {
      handleToggleAutoMaster();
    }

    if (typeof action.youtubeMuted === 'boolean' && action.youtubeMuted !== channelMuted[4]) {
      handleToggleMute(4);
    }

    if (typeof action.youtubeGainDelta === 'number') {
      const nextGain = Math.max(
        0,
        Math.min(1.2, Number((channelGains[4] + action.youtubeGainDelta).toFixed(2)))
      );
      handleChannelGain(4, nextGain);
    }

    if (action.recordingAction === 'start' && !telemetry.isRecording) {
      handleToggleRecord();
    } else if (action.recordingAction === 'stop' && telemetry.isRecording) {
      handleToggleRecord();
    }

    showToast(action.actionSummary);
  };

  const voice = useVoiceCommands({ onExecuteAction: handleExecuteVoiceAction });

  return (
    <div className="min-h-screen bg-[#0B0C10] text-slate-100 pb-20 lg:pb-8">
      {/* 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 border-b border-white/10 bg-[#0B0C10]/95 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between gap-8 px-4 sm:px-6">
          {/* Zone 1: Single-line Brand Title */}
          <button
            type="button"
            onClick={() => setActiveTab('mixer')}
            className="text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0"
          >
            AudioMaster Pro
          </button>

          {/* Zone 2: Desktop Single-Line Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-400">
            <button
              type="button"
              onClick={() => setActiveTab('mixer')}
              className={`whitespace-nowrap shrink-0 transition-colors ${
                activeTab === 'mixer' ? 'text-white' : 'hover:text-white'
              }`}
            >
              Studio Mixer
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('youtube')}
              className={`whitespace-nowrap shrink-0 transition-colors ${
                activeTab === 'youtube' ? 'text-white' : 'hover:text-white'
              }`}
            >
              YouTube Deck
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('ai')}
              className={`whitespace-nowrap shrink-0 transition-colors ${
                activeTab === 'ai' ? 'text-white' : 'hover:text-white'
              }`}
            >
              AI Mastering
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('apk')}
              className={`whitespace-nowrap shrink-0 transition-colors ${
                activeTab === 'apk' ? 'text-white' : 'hover:text-white'
              }`}
            >
              APK & Sync
            </button>
          </nav>

          {/* Zone 3: Single Primary Action */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={handlePrimaryHeaderAction}
              className="min-h-[40px] inline-flex items-center gap-2 rounded-xl bg-emerald-500 px-3.5 py-2 text-xs font-semibold text-slate-950 transition-colors hover:bg-emerald-400 whitespace-nowrap shrink-0"
            >
              {isInstallable ? (
                <>
                  <Smartphone className="h-4 w-4" />
                  <span>Install App</span>
                </>
              ) : (
                <>
                  <Download className="h-4 w-4" />
                  <span>{isInstalled ? 'Source APK (.zip)' : 'Source APK (.zip)'}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Main Studio Workspace */}
      <main className="mx-auto max-w-7xl px-4 py-4 sm:px-6 sm:py-6">
        {/* Clean Unboxed Telemetry Context Bar */}
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-medium text-slate-200">5-CH Real-Time Vocal DSP</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">{telemetry.sampleRate / 1000} kHz</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">
              Sync Drift {telemetry.syncDriftMs} ms
            </span>
            <span aria-hidden="true">·</span>
            <span className="truncate max-w-[220px] sm:max-w-xs text-slate-300">
              {youtubePlaying ? `Memutar: ${activeTrack.title}` : `Siap: ${activeTrack.title}`}
            </span>
          </div>
        </div>

        {/* Desktop Split Layout when on Mixer or YouTube, or dedicated Tab Views */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          {/* Left/Primary Column: Mixer Console or AI or APK */}
          <div
            className={
              activeTab === 'mixer'
                ? 'lg:col-span-7 block'
                : activeTab === 'youtube'
                ? 'hidden lg:block lg:col-span-7'
                : 'lg:col-span-12 block'
            }
          >
            {(activeTab === 'mixer' || activeTab === 'youtube') && (
              <div className="flex flex-col gap-4">
                <VoiceCommandBar
                  isSupported={voice.isSupported}
                  isListening={voice.isListening}
                  requireWakeWord={voice.requireWakeWord}
                  language={voice.language}
                  interimTranscript={voice.interimTranscript}
                  lastError={voice.lastError}
                  isProcessingAi={voice.isProcessingAi}
                  history={voice.history}
                  onToggleListening={voice.toggleListening}
                  onToggleWakeWord={() => voice.setRequireWakeWord((w) => !w)}
                  onChangeLanguage={voice.setLanguage}
                  onSubmitManualCommand={(text) => void voice.submitManualCommand(text)}
                />
                <MixerConsole
                  telemetry={telemetry}
                  channelGains={channelGains}
                  channelMuted={channelMuted}
                  selectedEqChannel={selectedEqChannel}
                  channelEqs={channelEqs}
                  compressor={compressor}
                  harmony={harmony}
                  delayMix={delayMix}
                  delayTimeMs={delayTimeMs}
                  autoMasterEnabled={autoMasterEnabled}
                  recordedWavUrl={recordedWavUrl}
                  onSelectEqChannel={setSelectedEqChannel}
                  onChangeChannelGain={handleChannelGain}
                  onToggleChannelMute={handleToggleMute}
                  onChangeEq={handleChangeEq}
                  onResetEq={handleResetEq}
                  onChangeCompressor={handleChangeCompressor}
                  onChangeHarmony={handleChangeHarmony}
                  onChangeDelay={handleChangeDelay}
                  onToggleAutoMaster={handleToggleAutoMaster}
                  onToggleMic={handleToggleMic}
                  onToggleTestVocal={handleToggleTestVocal}
                  onToggleBacking={handleToggleBacking}
                  onToggleRecord={handleToggleRecord}
                  onUploadBacking={handleUploadBacking}
                />
              </div>
            )}

            {activeTab === 'ai' && (
              <AiMasteringPanel
                activeTrack={activeTrack}
                telemetry={telemetry}
                externalPreset={externalAiPreset}
                isGeneratingExternal={isGeneratingFromYt}
                onApplyPreset={applyAiPresetToDsp}
                onApplyDiagnosis={applyAiDiagnosis}
              />
            )}

            {activeTab === 'apk' && (
              <SyncAndApkPanel
                telemetry={telemetry}
                isInstallable={isInstallable}
                isInstalled={isInstalled}
                isIOS={isIOS}
                onInstallPwa={() => void install()}
                onChangeSyncOffset={(ms) => engineRef.current?.setSyncOffsetMs(ms)}
                onAutoCalibrateSync={() => {
                  const res = engineRef.current?.calibrateSync();
                  if (res) showToast(`Sync terkalibrasi: ${res.offsetMs} ms`);
                }}
              />
            )}
          </div>

          {/* Persistent YouTube Deck (stays mounted so background audio keeps playing across tabs!) */}
          <div
            className={
              activeTab === 'youtube'
                ? 'lg:col-span-5 block'
                : activeTab === 'mixer'
                ? 'hidden lg:block lg:col-span-5'
                : 'hidden'
            }
          >
            <YouTubePlayerDeck
              youtubeVolume={channelGains[4]}
              youtubeMuted={channelMuted[4]}
              systemAudioActive={telemetry.systemAudioActive}
              onToggleSystemAudio={() => void handleToggleSystemAudio()}
              onTrackChange={setActiveTrack}
              onPlayingStateChange={setYoutubePlaying}
              onAiAutoMasterTrack={(track) => void handleAiAutoMasterFromTrack(track)}
            />
          </div>
        </div>
      </main>

      {/* Mobile Bottom Navigation Bar (Thumb Zone) */}
      <nav
        aria-label="Mobile navigation"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-40 border-t border-white/10 bg-[#0B0C10]/95 backdrop-blur-md pb-safe"
      >
        <div className="grid grid-cols-4 h-16 items-center">
          <button
            type="button"
            onClick={() => setActiveTab('mixer')}
            className={`min-h-[44px] flex flex-col items-center justify-center gap-1 transition-colors ${
              activeTab === 'mixer' ? 'text-emerald-400' : 'text-slate-400'
            }`}
          >
            <Sliders className="h-5 w-5" />
            <span className="text-[11px] font-medium tracking-tight">Mixer</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('youtube')}
            className={`min-h-[44px] flex flex-col items-center justify-center gap-1 transition-colors ${
              activeTab === 'youtube' ? 'text-rose-400' : 'text-slate-400'
            }`}
          >
            <Youtube className="h-5 w-5" />
            <span className="text-[11px] font-medium tracking-tight">YouTube</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('ai')}
            className={`min-h-[44px] flex flex-col items-center justify-center gap-1 transition-colors ${
              activeTab === 'ai' ? 'text-sky-400' : 'text-slate-400'
            }`}
          >
            <Sparkles className="h-5 w-5" />
            <span className="text-[11px] font-medium tracking-tight">AI Master</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('apk')}
            className={`min-h-[44px] flex flex-col items-center justify-center gap-1 transition-colors ${
              activeTab === 'apk' ? 'text-amber-400' : 'text-slate-400'
            }`}
          >
            <Smartphone className="h-5 w-5" />
            <span className="text-[11px] font-medium tracking-tight">APK & Sync</span>
          </button>
        </div>
      </nav>

      {/* Non-intrusive Toast & Offline Banner */}
      {toastMsg && (
        <div className="fixed bottom-20 lg:bottom-6 right-4 z-50 flex items-center gap-2 rounded-xl border border-emerald-500/40 bg-[#13151B] px-4 py-2.5 text-xs font-medium text-white shadow-xl">
          <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
          <span>{toastMsg}</span>
        </div>
      )}

      {!isOnline && (
        <div className="fixed bottom-20 lg:bottom-6 left-4 z-50 flex items-center gap-2 rounded-xl bg-amber-500 px-3.5 py-2 text-xs font-semibold text-slate-950 shadow-lg">
          <WifiOff className="h-4 w-4" />
          <span>Mode Offline — DSP Lokal Tetap Aktif</span>
        </div>
      )}
    </div>
  );
}
