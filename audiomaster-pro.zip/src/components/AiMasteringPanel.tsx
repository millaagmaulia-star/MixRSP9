import React, { useState } from 'react';
import { Sparkles, Activity, CheckCircle2, SlidersHorizontal, AlertTriangle } from 'lucide-react';
import {
  HarmonyMode,
  MUSICAL_KEYS,
  MasteringTelemetry,
} from '../audio/AudioDspEngine';
import { YouTubeTrackInfo } from './YouTubePlayerDeck';

export interface AiMasteringPreset {
  presetName: string;
  detectedKeyIndex: number;
  scaleMode: string;
  harmonyInterval: HarmonyMode;
  harmonyMix: number;
  compressor: {
    thresholdDb: number;
    ratio: number;
    attackMs: number;
    releaseMs: number;
    makeupDb: number;
  };
  vocalEq: {
    lowDb: number;
    midDb: number;
    highDb: number;
  };
  youtubeEq: {
    lowDb: number;
    midDb: number;
    highDb: number;
  };
  delayMix: number;
  delayTimeMs: number;
  autoDuckAmount: number;
  masteringNotes: string;
}

export interface AiVocalDiagnosis {
  healthStatus: string;
  vocalDiagnosis: string;
  recommendedAction: string;
  suggestedThresholdDb: number;
  suggestedHighBoostDb: number;
  suggestedMidCutDb: number;
  suggestedSyncOffsetMs: number;
}

interface AiMasteringPanelProps {
  activeTrack: YouTubeTrackInfo;
  telemetry: MasteringTelemetry;
  externalPreset: AiMasteringPreset | null;
  isGeneratingExternal: boolean;
  onApplyPreset: (preset: AiMasteringPreset) => void;
  onApplyDiagnosis: (diag: AiVocalDiagnosis) => void;
}

const GENRE_OPTIONS = [
  'Pop Karaoke',
  'Acoustic Ballad',
  'Dangdut / Koplo',
  'R&B / Soul',
  'Rock Live',
  'Podcast / Broadcast',
];

const VOCAL_STYLES = [
  'Balanced Studio',
  'Warm & Intimate',
  'Bright Pop Presence',
  'Arena Live Reverb',
  'Crisp Broadcast',
];

export const AiMasteringPanel: React.FC<AiMasteringPanelProps> = ({
  activeTrack,
  telemetry,
  externalPreset,
  isGeneratingExternal,
  onApplyPreset,
  onApplyDiagnosis,
}) => {
  const [songInput, setSongInput] = useState(activeTrack.title);
  const [genre, setGenre] = useState(GENRE_OPTIONS[0]);
  const [vocalStyle, setVocalStyle] = useState(VOCAL_STYLES[0]);
  const [notes, setNotes] = useState('');

  const [preset, setPreset] = useState<AiMasteringPreset | null>(externalPreset);
  const [diagnosis, setDiagnosis] = useState<AiVocalDiagnosis | null>(null);
  const [loadingPreset, setLoadingPreset] = useState(false);
  const [loadingDiag, setLoadingDiag] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [appliedBanner, setAppliedBanner] = useState<string | null>(null);

  const displayedPreset = preset || externalPreset;

  const handleGeneratePreset = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoadingPreset(true);
    setErrorMsg(null);
    setAppliedBanner(null);

    try {
      const res = await fetch('/api/ai/mastering-preset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          songTitle: songInput || activeTrack.title,
          genre,
          vocalStyle,
          notes,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(data.error || 'Gagal membuat preset mastering AI.');
        return;
      }
      setPreset(data as AiMasteringPreset);
      onApplyPreset(data as AiMasteringPreset);
      setAppliedBanner(`Preset "${data.presetName}" diterapkan otomatis ke DSP!`);
    } catch {
      setErrorMsg('Koneksi ke server AI gagal.');
    } finally {
      setLoadingPreset(false);
    }
  };

  const handleAnalyzeTelemetry = async () => {
    setLoadingDiag(true);
    setErrorMsg(null);
    setAppliedBanner(null);

    try {
      const res = await fetch('/api/ai/analyze-vocal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rmsDb: telemetry.vocalRmsDb,
          peakDb: telemetry.vocalPeakDb,
          pitchHz: telemetry.detectedPitchHz,
          detectedNote: telemetry.detectedNote,
          gainReductionDb: telemetry.gainReductionDb,
          syncDriftMs: telemetry.syncDriftMs,
          bufferFillPct: telemetry.bufferFillPct,
          youtubeTitle: activeTrack.title,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(data.error || 'Gagal menganalisis telemetri vokal.');
        return;
      }
      setDiagnosis(data as AiVocalDiagnosis);
    } catch {
      setErrorMsg('Koneksi ke server diagnostik AI gagal.');
    } finally {
      setLoadingDiag(false);
    }
  };

  return (
    <div className="flex flex-col gap-4">
      {errorMsg && (
        <div
          role="alert"
          className="flex items-start gap-2.5 rounded-xl border border-rose-500/40 bg-rose-500/10 p-3.5 text-xs text-rose-200"
        >
          <AlertTriangle className="h-4 w-4 shrink-0 text-rose-400 mt-0.5" />
          <span>{errorMsg}</span>
        </div>
      )}

      {appliedBanner && (
        <div className="flex items-center gap-2 rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-3 text-xs font-medium text-emerald-300">
          <CheckCircle2 className="h-4 w-4 shrink-0" />
          <span>{appliedBanner}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* AI Automated Vocal Mastering Chain Generator */}
        <section className="rounded-2xl border border-white/10 bg-[#13151B] p-4 sm:p-5">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h2 className="text-base font-semibold text-white">
                AI Automated Vocal Mastering
              </h2>
              <p className="text-xs text-slate-400">
                Kalkulasi Compressor, EQ 3-Band, Kunci Nada & Smart Harmony otomatis
              </p>
            </div>
            <Sparkles className="h-5 w-5 text-emerald-400 shrink-0" />
          </div>

          <form onSubmit={handleGeneratePreset} className="mt-4 flex flex-col gap-3">
            <label className="flex flex-col gap-1">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-300">Lagu / Konteks YouTube</span>
                <button
                  type="button"
                  onClick={() => setSongInput(activeTrack.title)}
                  className="text-[11px] font-medium text-emerald-400 hover:underline"
                >
                  Pakai Lagu Aktif
                </button>
              </div>
              <input
                type="text"
                value={songInput}
                onChange={(e) => setSongInput(e.target.value)}
                placeholder="Misal: Lagu Pop Ballad dalam C Mayor..."
                className="min-h-[44px] rounded-xl border border-white/10 bg-[#0B0C10] px-3.5 text-sm text-white placeholder:text-slate-500 focus:border-emerald-500 focus:outline-none"
              />
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label className="flex flex-col gap-1">
                <span className="text-xs font-medium text-slate-300">Genre Musik</span>
                <select
                  value={genre}
                  onChange={(e) => setGenre(e.target.value)}
                  className="min-h-[44px] rounded-xl border border-white/10 bg-[#0B0C10] px-3 text-sm text-white focus:border-emerald-500 focus:outline-none"
                >
                  {GENRE_OPTIONS.map((g) => (
                    <option key={g} value={g}>
                      {g}
                    </option>
                  ))}
                </select>
              </label>

              <label className="flex flex-col gap-1">
                <span className="text-xs font-medium text-slate-300">Karakter Vokal</span>
                <select
                  value={vocalStyle}
                  onChange={(e) => setVocalStyle(e.target.value)}
                  className="min-h-[44px] rounded-xl border border-white/10 bg-[#0B0C10] px-3 text-sm text-white focus:border-emerald-500 focus:outline-none"
                >
                  {VOCAL_STYLES.map((v) => (
                    <option key={v} value={v}>
                      {v}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            <label className="flex flex-col gap-1">
              <span className="text-xs font-medium text-slate-300">Catatan Tambahan (Opsional)</span>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Misal: Mic kondensor agak sibilant, butuh ruang vokal..."
                className="min-h-[44px] rounded-xl border border-white/10 bg-[#0B0C10] px-3.5 text-sm text-white placeholder:text-slate-500 focus:border-emerald-500 focus:outline-none"
              />
            </label>

            <button
              type="submit"
              disabled={loadingPreset || isGeneratingExternal}
              className="mt-1 min-h-[48px] inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-500 px-5 text-sm font-semibold text-slate-950 transition-colors hover:bg-emerald-400 disabled:opacity-50"
            >
              <SlidersHorizontal className="h-4 w-4" />
              {loadingPreset || isGeneratingExternal
                ? 'Mengkalibrasi DSP...'
                : 'Generate & Terapkan Mastering AI'}
            </button>
          </form>

          {displayedPreset && (
            <div className="mt-4 rounded-xl border border-white/8 bg-[#0B0C10] p-3.5">
              <div className="flex items-center justify-between gap-2">
                <h3 className="text-sm font-semibold text-white">{displayedPreset.presetName}</h3>
                <span className="font-mono text-xs text-emerald-400">
                  Key {MUSICAL_KEYS[displayedPreset.detectedKeyIndex] || 'C'} {displayedPreset.scaleMode}
                </span>
              </div>
              <p className="mt-1.5 text-xs leading-relaxed text-slate-300">
                {displayedPreset.masteringNotes}
              </p>
              <div className="mt-3 grid grid-cols-3 gap-2 border-t border-white/8 pt-3 text-xs font-mono tabular-nums">
                <div>
                  <span className="text-slate-500 block">Comp Thresh</span>
                  <span className="text-white">{displayedPreset.compressor.thresholdDb} dB</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Ratio / Gain</span>
                  <span className="text-white">
                    {displayedPreset.compressor.ratio}:1 / +{displayedPreset.compressor.makeupDb}dB
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Harmony / Dly</span>
                  <span className="text-white">
                    {Math.round(displayedPreset.harmonyMix * 100)}% /{' '}
                    {Math.round(displayedPreset.delayMix * 100)}%
                  </span>
                </div>
              </div>
            </div>
          )}
        </section>

        {/* Live Telemetry Vocal & Sync Diagnostics */}
        <section className="rounded-2xl border border-white/10 bg-[#13151B] p-4 sm:p-5 flex flex-col justify-between gap-4">
          <div>
            <div className="flex items-center justify-between gap-2">
              <div>
                <h2 className="text-base font-semibold text-white">
                  AI Vocal & Sync Telemetry Audit
                </h2>
                <p className="text-xs text-slate-400">
                  Analisis real-time headroom vokal, clipping, pitch & sinkronisasi buffer
                </p>
              </div>
              <Activity className="h-5 w-5 text-sky-400 shrink-0" />
            </div>

            <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-2.5 rounded-xl border border-white/8 bg-[#0B0C10] p-3.5 text-xs font-mono tabular-nums">
              <div>
                <span className="text-slate-500 block">Vocal RMS</span>
                <span className="text-sm font-semibold text-white">{telemetry.vocalRmsDb} dBFS</span>
              </div>
              <div>
                <span className="text-slate-500 block">Vocal Peak</span>
                <span className="text-sm font-semibold text-white">{telemetry.vocalPeakDb} dBFS</span>
              </div>
              <div>
                <span className="text-slate-500 block">Comp GR</span>
                <span className="text-sm font-semibold text-amber-400">
                  {telemetry.gainReductionDb} dB
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Pitch / Note</span>
                <span className="text-sm font-semibold text-emerald-400">
                  {telemetry.detectedNote} · {telemetry.detectedPitchHz}Hz
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Sync Drift</span>
                <span className="text-sm font-semibold text-sky-400">
                  {telemetry.syncDriftMs} ms
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Buffer Fill</span>
                <span className="text-sm font-semibold text-white">{telemetry.bufferFillPct}%</span>
              </div>
            </div>

            {diagnosis && (
              <div className="mt-4 rounded-xl border border-sky-500/30 bg-sky-500/10 p-3.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-sky-300">
                    Status: {diagnosis.healthStatus}
                  </span>
                  <span className="font-mono text-xs text-slate-300">
                    Offset {diagnosis.suggestedSyncOffsetMs} ms
                  </span>
                </div>
                <p className="mt-1.5 text-xs text-slate-200">{diagnosis.vocalDiagnosis}</p>
                <p className="mt-1 text-xs text-slate-400">{diagnosis.recommendedAction}</p>
                <button
                  type="button"
                  onClick={() => {
                    onApplyDiagnosis(diagnosis);
                    setAppliedBanner('Kalibrasi AI Telemetry diterapkan ke Compressor, EQ & Sync!');
                  }}
                  className="mt-3 min-h-[40px] inline-flex items-center gap-2 rounded-lg bg-sky-500 px-3.5 text-xs font-semibold text-slate-950 hover:bg-sky-400"
                >
                  <CheckCircle2 className="h-4 w-4" />
                  Terapkan Kalibrasi Otomatis
                </button>
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={handleAnalyzeTelemetry}
            disabled={loadingDiag}
            className="min-h-[48px] w-full inline-flex items-center justify-center gap-2 rounded-xl border border-sky-500/40 bg-sky-500/15 px-5 text-sm font-semibold text-sky-200 transition-colors hover:bg-sky-500/25 disabled:opacity-50"
          >
            <Activity className="h-4 w-4" />
            {loadingDiag ? 'Menganalisis Telemetri...' : 'Audit Vokal & Sync Real-Time'}
          </button>
        </section>
      </div>
    </div>
  );
};
