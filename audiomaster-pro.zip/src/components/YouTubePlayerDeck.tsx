import React, { useEffect, useRef, useState } from 'react';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Search,
  Radio,
  Sparkles,
  MonitorSpeaker,
  ExternalLink,
} from 'lucide-react';

export interface YouTubeTrackInfo {
  videoId: string;
  title: string;
  author: string;
  thumbnailUrl?: string;
}

interface YTPlayerInstance {
  loadVideoById: (id: string) => void;
  playVideo: () => void;
  pauseVideo: () => void;
  setVolume: (vol: number) => void;
  mute: () => void;
  unMute: () => void;
  getCurrentTime: () => number;
  getDuration: () => number;
  seekTo: (seconds: number, allowSeekAhead: boolean) => void;
  destroy: () => void;
}

declare global {
  interface Window {
    YT?: {
      Player: new (
        el: HTMLElement | string,
        opts: {
          videoId: string;
          playerVars?: Record<string, string | number>;
          events?: {
            onReady?: (e: { target: YTPlayerInstance }) => void;
            onStateChange?: (e: { data: number }) => void;
          };
        }
      ) => YTPlayerInstance;
      PlayerState?: {
        PLAYING: number;
        PAUSED: number;
        ENDED: number;
        BUFFERING: number;
      };
    };
    onYouTubeIframeAPIReady?: () => void;
  }
}

const PRESET_KARAOKE_TRACKS: YouTubeTrackInfo[] = [
  {
    videoId: 'jfKfPfyJRdk',
    title: 'Lofi Hip Hop Radio — Smooth Backing Groove',
    author: 'Lofi Girl',
  },
  {
    videoId: '5qap5aO4i9A',
    title: 'Chill Synth & Rhodes Instrumental Session',
    author: 'Studio Backing',
  },
  {
    videoId: 'DWcJFNfaw9c',
    title: 'Acoustic Ballad Backing Track in C Major',
    author: 'Karaoke Backing',
  },
  {
    videoId: '7NOSDKb0HlU',
    title: 'Soulful R&B Guitar Jam Track (90 BPM)',
    author: 'Jam Tracks',
  },
];

interface YouTubePlayerDeckProps {
  youtubeVolume: number; // 0..1.2
  youtubeMuted: boolean;
  systemAudioActive: boolean;
  onToggleSystemAudio: () => void;
  onTrackChange: (track: YouTubeTrackInfo) => void;
  onPlayingStateChange: (playing: boolean) => void;
  onAiAutoMasterTrack: (track: YouTubeTrackInfo) => void;
  compact?: boolean;
}

function formatTime(sec: number): string {
  if (!Number.isFinite(sec) || sec <= 0) return '0:00';
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}

export const YouTubePlayerDeck: React.FC<YouTubePlayerDeckProps> = ({
  youtubeVolume,
  youtubeMuted,
  systemAudioActive,
  onToggleSystemAudio,
  onTrackChange,
  onPlayingStateChange,
  onAiAutoMasterTrack,
  compact = false,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const playerRef = useRef<YTPlayerInstance | null>(null);

  const [urlInput, setUrlInput] = useState('');
  const [currentTrack, setCurrentTrack] = useState<YouTubeTrackInfo>(PRESET_KARAOKE_TRACKS[0]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isResolving, setIsResolving] = useState(false);
  const [resolveError, setResolveError] = useState<string | null>(null);
  const [playerReady, setPlayerReady] = useState(false);

  // Initialize YouTube IFrame API once
  useEffect(() => {
    onTrackChange(currentTrack);

    const initPlayer = () => {
      if (!containerRef.current || !window.YT?.Player || playerRef.current) return;
      playerRef.current = new window.YT.Player(containerRef.current, {
        videoId: currentTrack.videoId,
        playerVars: {
          playsinline: 1,
          rel: 0,
          modestbranding: 1,
          enablejsapi: 1,
          origin: window.location.origin,
        },
        events: {
          onReady: (ev) => {
            setPlayerReady(true);
            ev.target.setVolume(Math.min(100, Math.round(youtubeVolume * 100)));
            if (youtubeMuted) ev.target.mute();
          },
          onStateChange: (ev) => {
            const playing = ev.data === 1;
            setIsPlaying(playing);
            onPlayingStateChange(playing);
            if ('mediaSession' in navigator) {
              navigator.mediaSession.playbackState = playing ? 'playing' : 'paused';
            }
          },
        },
      });
    };

    if (window.YT?.Player) {
      initPlayer();
    } else {
      const existingScript = document.querySelector('script[src="https://www.youtube.com/iframe_api"]');
      if (!existingScript) {
        const tag = document.createElement('script');
        tag.src = 'https://www.youtube.com/iframe_api';
        document.body.appendChild(tag);
      }
      const prevCallback = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => {
        prevCallback?.();
        initPlayer();
      };
    }

    return () => {
      playerRef.current?.destroy();
      playerRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Sync CH 5 fader & mute to YouTube IFrame Player
  useEffect(() => {
    if (!playerRef.current || !playerReady) return;
    playerRef.current.setVolume(Math.min(100, Math.round(youtubeVolume * 100)));
    if (youtubeMuted) {
      playerRef.current.mute();
    } else {
      playerRef.current.unMute();
    }
  }, [youtubeVolume, youtubeMuted, playerReady]);

  // Update MediaSession metadata for background mobile lock-screen controls
  useEffect(() => {
    if ('mediaSession' in navigator) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: currentTrack.title,
        artist: `${currentTrack.author} · AudioMaster Pro`,
        artwork: currentTrack.thumbnailUrl
          ? [{ src: currentTrack.thumbnailUrl, sizes: '480x360', type: 'image/jpeg' }]
          : [],
      });
      navigator.mediaSession.setActionHandler('play', () => playerRef.current?.playVideo());
      navigator.mediaSession.setActionHandler('pause', () => playerRef.current?.pauseVideo());
    }
  }, [currentTrack]);

  // Playback progress ticker
  useEffect(() => {
    const id = window.setInterval(() => {
      if (playerRef.current && isPlaying) {
        setCurrentTime(playerRef.current.getCurrentTime() || 0);
        setDuration(playerRef.current.getDuration() || 0);
      }
    }, 500);
    return () => window.clearInterval(id);
  }, [isPlaying]);

  const loadTrack = (track: YouTubeTrackInfo) => {
    setCurrentTrack(track);
    onTrackChange(track);
    setResolveError(null);
    if (playerRef.current && playerReady) {
      playerRef.current.loadVideoById(track.videoId);
    }
  };

  const handleResolveSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!urlInput.trim()) return;
    setIsResolving(true);
    setResolveError(null);

    try {
      const res = await fetch(`/api/youtube/resolve?url=${encodeURIComponent(urlInput.trim())}`);
      const data = await res.json();
      if (!res.ok) {
        setResolveError(data.error || 'URL YouTube tidak valid.');
        return;
      }
      loadTrack(data as YouTubeTrackInfo);
      setUrlInput('');
    } catch {
      setResolveError('Gagal memuat metadata YouTube.');
    } finally {
      setIsResolving(false);
    }
  };

  const togglePlay = () => {
    if (!playerRef.current || !playerReady) return;
    if (isPlaying) {
      playerRef.current.pauseVideo();
    } else {
      playerRef.current.playVideo();
    }
  };

  return (
    <section className="flex flex-col gap-4 rounded-2xl border border-white/10 bg-[#13151B] p-4 sm:p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-semibold tracking-tight text-white">
            YouTube Background & Karaoke Deck
          </h2>
          <p className="text-xs text-slate-400">
            Channel 5 · Streaming langsung terhubung ke fader & background playback
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onToggleSystemAudio}
            className={`min-h-[44px] inline-flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap ${
              systemAudioActive
                ? 'bg-emerald-500 text-slate-950'
                : 'border border-white/10 bg-white/5 text-slate-200 hover:bg-white/10'
            }`}
          >
            <MonitorSpeaker className="h-4 w-4" />
            {systemAudioActive ? 'DSP Audio Terhubung' : 'Tangkap Audio ke DSP'}
          </button>
        </div>
      </div>

      {/* URL / Video ID Resolver */}
      <form onSubmit={handleResolveSubmit} className="flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            placeholder="Tempel link YouTube karaoke / lagu atau Video ID..."
            className="min-h-[44px] w-full rounded-xl border border-white/10 bg-[#0B0C10] pl-10 pr-4 text-sm text-white placeholder:text-slate-500 focus:border-emerald-500 focus:outline-none"
          />
        </div>
        <button
          type="submit"
          disabled={isResolving}
          className="min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-500 px-5 py-2.5 text-sm font-semibold text-slate-950 transition-colors hover:bg-emerald-400 disabled:opacity-50 whitespace-nowrap"
        >
          <Radio className="h-4 w-4" />
          {isResolving ? 'Memuat...' : 'Putar YouTube'}
        </button>
      </form>

      {resolveError && (
        <p className="text-xs text-rose-400" role="alert">
          {resolveError}
        </p>
      )}

      {/* Embedded YouTube Player Frame */}
      <div
        className={`relative w-full overflow-hidden rounded-xl border border-white/10 bg-black ${
          compact ? 'aspect-video max-h-[220px]' : 'aspect-video'
        }`}
      >
        <div ref={containerRef} className="h-full w-full" />
      </div>

      {/* Transport & Background Controls */}
      <div className="flex flex-col gap-3 rounded-xl border border-white/8 bg-[#0B0C10] p-3.5">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold text-white">{currentTrack.title}</p>
            <div className="mt-0.5 flex items-center gap-2 text-xs text-slate-400">
              <span className="truncate">{currentTrack.author}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums">
                {formatTime(currentTime)} / {formatTime(duration)}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={togglePlay}
              aria-label={isPlaying ? 'Pause YouTube' : 'Play YouTube'}
              className="min-h-[44px] min-w-[44px] inline-flex items-center justify-center rounded-xl bg-white text-slate-950 transition-transform active:scale-95"
            >
              {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5 ml-0.5" />}
            </button>
            <button
              type="button"
              onClick={() => onAiAutoMasterTrack(currentTrack)}
              className="min-h-[44px] inline-flex items-center gap-1.5 rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-3 text-xs font-semibold text-emerald-300 hover:bg-emerald-500/20 whitespace-nowrap"
            >
              <Sparkles className="h-4 w-4" />
              AI Auto-Master Lagu Ini
            </button>
          </div>
        </div>

        {/* Seek Bar */}
        <div className="flex items-center gap-3">
          {youtubeMuted ? (
            <VolumeX className="h-4 w-4 shrink-0 text-rose-400" />
          ) : (
            <Volume2 className="h-4 w-4 shrink-0 text-slate-400" />
          )}
          <input
            type="range"
            min={0}
            max={duration > 0 ? Math.floor(duration) : 100}
            value={Math.floor(currentTime)}
            onChange={(e) => {
              const sec = Number(e.target.value);
              setCurrentTime(sec);
              playerRef.current?.seekTo(sec, true);
            }}
            aria-label="Seek YouTube playback"
            className="studio-slider flex-1"
          />
          <span className="w-12 text-right font-mono text-xs tabular-nums text-slate-400">
            {Math.round(youtubeVolume * 100)}%
          </span>
        </div>
      </div>

      {/* Quick Karaoke / Backing Presets */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-medium text-slate-400">
            Streaming Cepat Musik Latar & Karaoke
          </span>
          <a
            href={`https://www.youtube.com/watch?v=${currentTrack.videoId}`}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1 text-xs text-slate-400 hover:text-white"
          >
            Buka di YouTube <ExternalLink className="h-3 w-3" />
          </a>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {PRESET_KARAOKE_TRACKS.map((track) => {
            const active = track.videoId === currentTrack.videoId;
            return (
              <button
                key={track.videoId}
                type="button"
                onClick={() => loadTrack(track)}
                className={`min-h-[48px] flex flex-col items-start justify-center rounded-xl border px-3.5 py-2 text-left transition-colors ${
                  active
                    ? 'border-emerald-500/60 bg-emerald-500/10 text-white'
                    : 'border-white/8 bg-[#0B0C10] text-slate-300 hover:border-white/20'
                }`}
              >
                <span className="w-full truncate text-xs font-semibold">{track.title}</span>
                <span className="text-[11px] text-slate-400">{track.author}</span>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};
