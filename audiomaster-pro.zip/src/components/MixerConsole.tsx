import React from 'react';
import {
  Mic,
  MicOff,
  Radio,
  Music2,
  Sliders,
  Disc,
  Download,
  VolumeX,
  Volume2,
  Upload,
  Wand2,
  RotateCcw,
} from 'lucide-react';
import {
  CompressorParams,
  EqBands,
  HarmonyMode,
  HarmonyParams,
  MUSICAL_KEYS,
  MasteringTelemetry,
} from '../audio/AudioDspEngine';

const CHANNEL_META = [
  { name: 'CH 1 · Vocal', role: 'Mic / Lead', accent: 'bg-sky-400', text: 'text-sky-400' },
  { name: 'CH 2 · Harmony', role: 'Smart DSP', accent: 'bg-emerald-400', text: 'text-emerald-400' },
  { name: 'CH 3 · Inst 1', role: 'Deck A', accent: 'bg-amber-400', text: 'text-amber-400' },
  { name: 'CH 4 · Inst 2', role: 'Deck B', accent: 'bg-orange-400', text: 'text-orange-400' },
  { name: 'CH 5 · YouTube', role: 'Stream Bus', accent: 'bg-rose-400', text: 'text-rose-400' },
];

interface MixerConsoleProps {
  telemetry: MasteringTelemetry;
  channelGains: [number, number, number, number, number];
  channelMuted: [boolean, boolean, boolean, boolean, boolean];
  selectedEqChannel: number;
  channelEqs: EqBands[];
  compressor: CompressorParams;
  harmony: HarmonyParams;
  delayMix: number;
  delayTimeMs: number;
  autoMasterEnabled: boolean;
  recordedWavUrl: string | null;
  onSelectEqChannel: (ch: number) => void;
  onChangeChannelGain: (ch: number, gain: number) => void;
  onToggleChannelMute: (ch: number) => void;
  onChangeEq: (ch: number, band: 'low' | 'mid' | 'high', db: number) => void;
  onResetEq: (ch: number) => void;
  onChangeCompressor: (partial: Partial<CompressorParams>) => void;
  onChangeHarmony: (partial: Partial<HarmonyParams>) => void;
  onChangeDelay: (mix: number, timeMs?: number) => void;
  onToggleAutoMaster: () => void;
  onToggleMic: () => void;
  onToggleTestVocal: () => void;
  onToggleBacking: () => void;
  onToggleRecord: () => void;
  onUploadBacking: (deck: 0 | 1, file: File) => void;
}

export const MixerConsole: React.FC<MixerConsoleProps> = ({
  telemetry,
  channelGains,
  channelMuted,
  selectedEqChannel,
  channelEqs,
  compressor,
  harmony,
  delayMix,
  delayTimeMs,
  autoMasterEnabled,
  recordedWavUrl,
  onSelectEqChannel,
  onChangeChannelGain,
  onToggleChannelMute,
  onChangeEq,
  onResetEq,
  onChangeCompressor,
  onChangeHarmony,
  onChangeDelay,
  onToggleAutoMaster,
  onToggleMic,
  onToggleTestVocal,
  onToggleBacking,
  onToggleRecord,
  onUploadBacking,
}) => {
  const activeEq = channelEqs[selectedEqChannel];

  return (
    <div className="flex flex-col gap-4">
      {/* Input Sources & Master Record Strip */}
      <section className="rounded-2xl border border-white/10 bg-[#13151B] p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={onToggleMic}
              className={`min-h-[44px] inline-flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
                telemetry.micActive
                  ? 'bg-sky-500 text-slate-950'
                  : 'border border-white/10 bg-white/5 text-slate-200 hover:bg-white/10'
              }`}
            >
              {telemetry.micActive ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
              {telemetry.micActive ? 'Mic Live ON' : 'Aktifkan Mic'}
            </button>

            <button
              type="button"
              onClick={onToggleTestVocal}
              className={`min-h-[44px] inline-flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap ${
                telemetry.testVocalActive
                  ? 'bg-emerald-500 text-slate-950'
                  : 'border border-white/10 bg-white/5 text-slate-200 hover:bg-white/10'
              }`}
            >
              <Radio className="h-4 w-4" />
              {telemetry.testVocalActive ? 'Vocal Synth ON' : 'Uji Vokal DSP'}
            </button>

            <button
              type="button"
              onClick={onToggleBacking}
              className={`min-h-[44px] inline-flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap ${
                telemetry.backingActive
                  ? 'bg-amber-500 text-slate-950'
                  : 'border border-white/10 bg-white/5 text-slate-200 hover:bg-white/10'
              }`}
            >
              <Music2 className="h-4 w-4" />
              {telemetry.backingActive ? 'Loop Musik ON' : 'Loop Backing'}
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onToggleAutoMaster}
              className={`min-h-[44px] inline-flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
                autoMasterEnabled
                  ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/40'
                  : 'border border-white/10 bg-white/5 text-slate-400'
              }`}
            >
              <Wand2 className="h-4 w-4" />
              Auto-Master {autoMasterEnabled ? 'ON' : 'OFF'}
            </button>

            <button
              type="button"
              onClick={onToggleRecord}
              className={`min-h-[44px] inline-flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
                telemetry.isRecording
                  ? 'bg-rose-600 text-white'
                  : 'border border-rose-500/40 bg-rose-500/10 text-rose-300 hover:bg-rose-500/20'
              }`}
            >
              <Disc className="h-4 w-4" />
              {telemetry.isRecording
                ? `Stop (${telemetry.recordingDurationSec}s)`
                : 'Rekam WAV'}
            </button>
          </div>
        </div>

        {/* Live Master Spectrum + Telemetry Readout */}
        <div className="mt-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 rounded-xl border border-white/8 bg-[#0B0C10] p-3">
          <div className="flex h-12 flex-1 items-end gap-1" aria-hidden="true">
            {telemetry.spectrumBins.map((val, idx) => (
              <div
                key={idx}
                className="flex-1 rounded-t-sm bg-emerald-400/80 transition-all duration-75"
                style={{
                  height: `${Math.max(8, Math.round(val * 100))}%`,
                  opacity: 0.35 + val * 0.65,
                }}
              />
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-4 text-xs font-mono tabular-nums text-slate-300">
            <div>
              <span className="text-slate-500">Pitch </span>
              <span className="font-semibold text-emerald-400">
                {telemetry.detectedNote} ({telemetry.detectedPitchHz} Hz)
              </span>
            </div>
            <div>
              <span className="text-slate-500">GR </span>
              <span className="font-semibold text-amber-400">{telemetry.gainReductionDb} dB</span>
            </div>
            <div>
              <span className="text-slate-500">Master </span>
              <span className="font-semibold text-white">{telemetry.masterPeakDb} dBFS</span>
            </div>
          </div>
        </div>

        {recordedWavUrl && (
          <div className="mt-3 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3">
            <audio controls src={recordedWavUrl} className="h-9 max-w-full flex-1" />
            <a
              href={recordedWavUrl}
              download={`AudioMasterPro_${Date.now()}.wav`}
              className="min-h-[44px] inline-flex items-center gap-2 rounded-xl bg-emerald-500 px-4 py-2 text-xs font-semibold text-slate-950 hover:bg-emerald-400 whitespace-nowrap"
            >
              <Download className="h-4 w-4" />
              Unduh Stereo .WAV
            </a>
          </div>
        )}
      </section>

      {/* Vocal Compressor + Smart Harmony DSP Rack */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Vocal Compressor Card */}
        <section className="rounded-2xl border border-white/10 bg-[#13151B] p-4">
          <div className="flex items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-semibold text-white">Vocal Compressor DSP</h3>
              <p className="text-xs text-slate-400">Dynamics control & makeup gain</p>
            </div>
            <button
              type="button"
              onClick={() => onChangeCompressor({ enabled: !compressor.enabled })}
              className={`min-h-[44px] rounded-xl px-4 text-xs font-semibold transition-colors whitespace-nowrap ${
                compressor.enabled
                  ? 'bg-sky-500 text-slate-950'
                  : 'border border-white/10 bg-white/5 text-slate-400'
              }`}
            >
              {compressor.enabled ? 'COMP ON' : 'COMP OFF'}
            </button>
          </div>

          <div className="mt-4 flex flex-col gap-3">
            <label className="flex flex-col gap-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Threshold</span>
                <span className="font-mono tabular-nums text-white">{compressor.thresholdDb} dB</span>
              </div>
              <input
                type="range"
                min={-40}
                max={0}
                step={1}
                value={compressor.thresholdDb}
                onChange={(e) => onChangeCompressor({ thresholdDb: Number(e.target.value) })}
                className="studio-slider w-full"
              />
            </label>

            <label className="flex flex-col gap-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Ratio</span>
                <span className="font-mono tabular-nums text-white">{compressor.ratio}:1</span>
              </div>
              <input
                type="range"
                min={1}
                max={12}
                step={0.5}
                value={compressor.ratio}
                onChange={(e) => onChangeCompressor({ ratio: Number(e.target.value) })}
                className="studio-slider w-full"
              />
            </label>

            <label className="flex flex-col gap-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Makeup Gain</span>
                <span className="font-mono tabular-nums text-white">+{compressor.makeupDb} dB</span>
              </div>
              <input
                type="range"
                min={0}
                max={12}
                step={0.5}
                value={compressor.makeupDb}
                onChange={(e) => onChangeCompressor({ makeupDb: Number(e.target.value) })}
                className="studio-slider w-full"
              />
            </label>
          </div>
        </section>

        {/* Smart Harmony DSP & Delay Card */}
        <section className="rounded-2xl border border-white/10 bg-[#13151B] p-4">
          <div className="flex items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-semibold text-white">Smart Harmony DSP</h3>
              <p className="text-xs text-slate-400 font-mono tabular-nums">
                Key {MUSICAL_KEYS[harmony.keyIndex]} · Shift +{telemetry.activeHarmonyInterval} st
              </p>
            </div>
            <button
              type="button"
              onClick={() => onChangeHarmony({ enabled: !harmony.enabled })}
              className={`min-h-[44px] rounded-xl px-4 text-xs font-semibold transition-colors whitespace-nowrap ${
                harmony.enabled
                  ? 'bg-emerald-500 text-slate-950'
                  : 'border border-white/10 bg-white/5 text-slate-400'
              }`}
            >
              {harmony.enabled ? 'HARMONY ON' : 'HARMONY OFF'}
            </button>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-2.5">
            <label className="flex flex-col gap-1">
              <span className="text-xs text-slate-400">Kunci Nada</span>
              <select
                value={harmony.keyIndex}
                onChange={(e) => onChangeHarmony({ keyIndex: Number(e.target.value) })}
                className="min-h-[44px] rounded-xl border border-white/10 bg-[#0B0C10] px-3 text-sm font-medium text-white focus:border-emerald-500 focus:outline-none"
              >
                {MUSICAL_KEYS.map((k, idx) => (
                  <option key={k} value={idx}>
                    Key: {k} Major
                  </option>
                ))}
              </select>
            </label>

            <label className="flex flex-col gap-1">
              <span className="text-xs text-slate-400">Interval Harmoni</span>
              <select
                value={harmony.mode}
                onChange={(e) => onChangeHarmony({ mode: e.target.value as HarmonyMode })}
                className="min-h-[44px] rounded-xl border border-white/10 bg-[#0B0C10] px-3 text-sm font-medium text-white focus:border-emerald-500 focus:outline-none"
              >
                <option value="smart_3rd">Smart Diatonic 3rd</option>
                <option value="fifth">Perfect 5th (+7 st)</option>
                <option value="octave">Octave (+12 st)</option>
                <option value="duet">Major Duet (+4 st)</option>
              </select>
            </label>
          </div>

          <div className="mt-3 grid grid-cols-2 gap-3">
            <label className="flex flex-col gap-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Harmony Mix</span>
                <span className="font-mono tabular-nums text-white">
                  {Math.round(harmony.mix * 100)}%
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                value={Math.round(harmony.mix * 100)}
                onChange={(e) => onChangeHarmony({ mix: Number(e.target.value) / 100 })}
                className="studio-slider w-full"
              />
            </label>

            <label className="flex flex-col gap-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Echo Delay ({delayTimeMs}ms)</span>
                <span className="font-mono tabular-nums text-white">
                  {Math.round(delayMix * 100)}%
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={80}
                value={Math.round(delayMix * 100)}
                onChange={(e) => onChangeDelay(Number(e.target.value) / 100)}
                className="studio-slider w-full"
              />
            </label>
          </div>
        </section>
      </div>

      {/* 3-Band Equalizer Strip */}
      <section className="rounded-2xl border border-white/10 bg-[#13151B] p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Sliders className="h-4 w-4 text-emerald-400" />
            <h3 className="text-sm font-semibold text-white">3-Band Channel Equalizer</h3>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex flex-wrap gap-1 rounded-xl bg-[#0B0C10] p-1">
              {CHANNEL_META.map((ch, idx) => (
                <button
                  key={ch.name}
                  type="button"
                  onClick={() => onSelectEqChannel(idx)}
                  className={`min-h-[36px] rounded-lg px-2.5 text-xs font-medium transition-colors whitespace-nowrap ${
                    selectedEqChannel === idx
                      ? 'bg-white/15 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  CH {idx + 1}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => onResetEq(selectedEqChannel)}
              aria-label="Reset channel EQ"
              className="min-h-[36px] min-w-[36px] inline-flex items-center justify-center rounded-lg border border-white/10 text-slate-400 hover:text-white"
            >
              <RotateCcw className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <label className="flex flex-col gap-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-sky-400 font-medium">LOW (100 Hz)</span>
              <span className="font-mono tabular-nums text-white">
                {activeEq.low > 0 ? `+${activeEq.low}` : activeEq.low} dB
              </span>
            </div>
            <input
              type="range"
              min={-12}
              max={12}
              step={1}
              value={activeEq.low}
              onChange={(e) => onChangeEq(selectedEqChannel, 'low', Number(e.target.value))}
              className="studio-slider w-full"
            />
          </label>

          <label className="flex flex-col gap-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-emerald-400 font-medium">MID (1 kHz)</span>
              <span className="font-mono tabular-nums text-white">
                {activeEq.mid > 0 ? `+${activeEq.mid}` : activeEq.mid} dB
              </span>
            </div>
            <input
              type="range"
              min={-12}
              max={12}
              step={1}
              value={activeEq.mid}
              onChange={(e) => onChangeEq(selectedEqChannel, 'mid', Number(e.target.value))}
              className="studio-slider w-full"
            />
          </label>

          <label className="flex flex-col gap-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-amber-400 font-medium">HIGH (8 kHz)</span>
              <span className="font-mono tabular-nums text-white">
                {activeEq.high > 0 ? `+${activeEq.high}` : activeEq.high} dB
              </span>
            </div>
            <input
              type="range"
              min={-12}
              max={12}
              step={1}
              value={activeEq.high}
              onChange={(e) => onChangeEq(selectedEqChannel, 'high', Number(e.target.value))}
              className="studio-slider w-full"
            />
          </label>
        </div>
      </section>

      {/* 5-Channel Mixing Console Faders (Responsive: Horizontal Touch Strips on Mobile, Vertical Strips on Desktop) */}
      <section className="rounded-2xl border border-white/10 bg-[#13151B] p-4">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-white">5-Channel Studio Console</h3>
          <span className="text-xs text-slate-400">Touch-optimized faders</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          {CHANNEL_META.map((ch, idx) => {
            const levelPct = Math.round((telemetry.channelLevels[idx] || 0) * 100);
            const muted = channelMuted[idx];
            const gainPct = Math.round(channelGains[idx] * 100);

            return (
              <div
                key={ch.name}
                className="flex flex-col gap-3 rounded-xl border border-white/8 bg-[#0B0C10] p-3"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <p className={`truncate text-xs font-semibold ${ch.text}`}>{ch.name}</p>
                    <p className="text-[11px] text-slate-500">{ch.role}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => onToggleChannelMute(idx)}
                    aria-label={muted ? `Unmute ${ch.name}` : `Mute ${ch.name}`}
                    className={`min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-lg border transition-colors ${
                      muted
                        ? 'border-rose-500/50 bg-rose-500/20 text-rose-300'
                        : 'border-white/10 bg-white/5 text-slate-300 hover:text-white'
                    }`}
                  >
                    {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                  </button>
                </div>

                {/* Live VU Bar */}
                <div className="h-2 w-full overflow-hidden rounded-full bg-white/5">
                  <div
                    className={`h-full transition-all duration-75 ${ch.accent}`}
                    style={{ width: `${muted ? 0 : levelPct}%` }}
                  />
                </div>

                {/* Fader Slider */}
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min={0}
                    max={120}
                    value={gainPct}
                    onChange={(e) => onChangeChannelGain(idx, Number(e.target.value) / 100)}
                    aria-label={`${ch.name} gain`}
                    className="studio-slider flex-1"
                  />
                  <span className="w-10 text-right font-mono text-xs tabular-nums text-white">
                    {gainPct}%
                  </span>
                </div>

                {/* Local Audio File Loader for CH 3 / CH 4 */}
                {(idx === 2 || idx === 3) && (
                  <label className="min-h-[38px] inline-flex cursor-pointer items-center justify-center gap-1.5 rounded-lg border border-dashed border-white/15 px-2 text-[11px] font-medium text-slate-300 hover:border-white/30 hover:text-white">
                    <Upload className="h-3.5 w-3.5" />
                    <span>Muat MP3/WAV</span>
                    <input
                      type="file"
                      accept="audio/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) onUploadBacking(idx === 2 ? 0 : 1, file);
                      }}
                    />
                  </label>
                )}
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
