import React, { useState } from 'react';
import {
  CheckCircle2,
  Cpu,
  Download,
  RefreshCw,
  Smartphone,
  Wrench,
  Code2,
} from 'lucide-react';
import { MasteringTelemetry } from '../audio/AudioDspEngine';
import {
  FIXED_ANDROID_MANIFEST_XML,
  FIXED_LOCKFREE_RINGBUFFER_H,
  FIXED_MIXER_ENGINE_CPP,
  SYNC_FIXES,
} from '../native/androidFixedTemplates';
import { downloadAndroidApkProjectZip } from '../native/apkZipBuilder';

interface SyncAndApkPanelProps {
  telemetry: MasteringTelemetry;
  isInstallable: boolean;
  isInstalled: boolean;
  isIOS: boolean;
  onInstallPwa: () => void;
  onChangeSyncOffset: (ms: number) => void;
  onAutoCalibrateSync: () => void;
}

type CodeTab = 'ringbuffer' | 'mixer' | 'manifest';

export const SyncAndApkPanel: React.FC<SyncAndApkPanelProps> = ({
  telemetry,
  isInstallable,
  isInstalled,
  isIOS,
  onInstallPwa,
  onChangeSyncOffset,
  onAutoCalibrateSync,
}) => {
  const [activeCodeTab, setActiveCodeTab] = useState<CodeTab>('ringbuffer');
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [showIosModal, setShowIosModal] = useState(false);

  const [showAndroidGuide, setShowAndroidGuide] = useState(false);

  const publicSiteUrl =
    typeof window !== 'undefined'
      ? window.location.origin.replace('ais-dev-', 'ais-pre-')
      : '';

  const handleDownloadApkZip = async () => {
    setDownloadingZip(true);
    try {
      await downloadAndroidApkProjectZip();
    } finally {
      setDownloadingZip(false);
    }
  };

  const codeContent =
    activeCodeTab === 'ringbuffer'
      ? FIXED_LOCKFREE_RINGBUFFER_H
      : activeCodeTab === 'mixer'
      ? FIXED_MIXER_ENGINE_CPP
      : FIXED_ANDROID_MANIFEST_XML;

  return (
    <div className="flex flex-col gap-4">
      {/* Top Grid: Live Sync Calibration + Mobile APK / PWA Export */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Live Audio Sync Calibration */}
        <section className="rounded-2xl border border-white/10 bg-[#13151B] p-4 sm:p-5">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h2 className="text-base font-semibold text-white">
                Audio Sync & Drift Calibration
              </h2>
              <p className="text-xs text-slate-400">
                Lock-free ring buffer timing · Kompensasi latensi mic & YouTube
              </p>
            </div>
            <Cpu className="h-5 w-5 text-emerald-400 shrink-0" />
          </div>

          <div className="mt-4 grid grid-cols-3 gap-2.5 rounded-xl border border-white/8 bg-[#0B0C10] p-3.5 text-xs font-mono tabular-nums">
            <div>
              <span className="text-slate-500 block">Sample Rate</span>
              <span className="text-sm font-semibold text-white">{telemetry.sampleRate} Hz</span>
            </div>
            <div>
              <span className="text-slate-500 block">HW Latency</span>
              <span className="text-sm font-semibold text-emerald-400">{telemetry.latencyMs} ms</span>
            </div>
            <div>
              <span className="text-slate-500 block">Ring Buffer</span>
              <span className="text-sm font-semibold text-sky-400">
                {telemetry.bufferFillPct}% · {telemetry.syncDriftMs}ms
              </span>
            </div>
          </div>

          <div className="mt-4 flex flex-col gap-3">
            <label className="flex flex-col gap-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300">Manual Sync Offset (Mic ↔ YouTube)</span>
                <span className="font-mono tabular-nums font-semibold text-white">
                  {telemetry.syncOffsetMs > 0 ? `+${telemetry.syncOffsetMs}` : telemetry.syncOffsetMs} ms
                </span>
              </div>
              <input
                type="range"
                min={-200}
                max={200}
                step={2}
                value={telemetry.syncOffsetMs}
                onChange={(e) => onChangeSyncOffset(Number(e.target.value))}
                className="studio-slider w-full"
              />
            </label>

            <button
              type="button"
              onClick={onAutoCalibrateSync}
              className="min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/5 px-4 text-xs font-semibold text-white hover:bg-white/10"
            >
              <RefreshCw className="h-4 w-4 text-emerald-400" />
              Auto-Kalibrasi Latensi Perangkat
            </button>
          </div>
        </section>

        {/* APK & Mobile App Installation */}
        <section className="rounded-2xl border border-white/10 bg-[#13151B] p-4 sm:p-5 flex flex-col justify-between gap-4">
          <div>
            <div className="flex items-center justify-between gap-2">
              <div>
                <h2 className="text-base font-semibold text-white">
                  Build APK & Mobile App Install
                </h2>
                <p className="text-xs text-slate-400">
                  Pasang langsung sebagai aplikasi Android/iOS atau ekspor source APK
                </p>
              </div>
              <Smartphone className="h-5 w-5 text-sky-400 shrink-0" />
            </div>

            <div className="mt-4 flex flex-col gap-2.5 text-xs text-slate-300">
              <div className="flex items-start gap-2 rounded-xl border border-white/8 bg-[#0B0C10] p-3">
                <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400 mt-0.5" />
                <div>
                  <p className="font-semibold text-white">1. WebAPK / PWA Standalone (Instan)</p>
                  <p className="text-slate-400 mt-0.5">
                    Berjalan fullscreen tanpa address bar browser dengan dukungan offline cache & media lock-screen.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-2 rounded-xl border border-white/8 bg-[#0B0C10] p-3">
                <CheckCircle2 className="h-4 w-4 shrink-0 text-sky-400 mt-0.5" />
                <div>
                  <p className="font-semibold text-white">2. Native Android Studio + Oboe C++ Bundle (.zip)</p>
                  <p className="text-slate-400 mt-0.5">
                    Sudah dilengkapi Lock-Free Ring Buffer, Async WAV Writer, YouTube WebView, dan GitHub Actions APK builder.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-2.5">
            <div className="flex flex-col sm:flex-row gap-2.5">
              {!isInstalled && isInstallable ? (
                <button
                  type="button"
                  onClick={onInstallPwa}
                  className="min-h-[48px] flex-1 inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-500 px-4 text-sm font-semibold text-slate-950 hover:bg-emerald-400"
                >
                  <Smartphone className="h-4 w-4" />
                  Install WebAPK ke Android
                </button>
              ) : !isInstalled && isIOS ? (
                <button
                  type="button"
                  onClick={() => setShowIosModal(true)}
                  className="min-h-[48px] flex-1 inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-500 px-4 text-sm font-semibold text-slate-950 hover:bg-emerald-400"
                >
                  <Smartphone className="h-4 w-4" />
                  Panduan Install iPhone/iPad
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setShowAndroidGuide(true)}
                  className="min-h-[48px] flex-1 inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-500 px-4 text-sm font-semibold text-slate-950 hover:bg-emerald-400"
                >
                  <Smartphone className="h-4 w-4" />
                  Cara Install / Unduh APK
                </button>
              )}
              <button
                type="button"
                onClick={handleDownloadApkZip}
                disabled={downloadingZip}
                className="min-h-[48px] flex-1 inline-flex items-center justify-center gap-2 rounded-xl border border-sky-500/40 bg-sky-500/15 px-4 text-sm font-semibold text-sky-200 hover:bg-sky-500/25 disabled:opacity-50"
              >
                <Download className="h-4 w-4" />
                {downloadingZip ? 'Menyiapkan ZIP...' : 'Unduh Source Project (.zip)'}
              </button>
              <a
                href={`https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(publicSiteUrl)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="min-h-[48px] flex-1 inline-flex items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/5 px-4 text-sm font-semibold text-white hover:bg-white/10 whitespace-nowrap"
              >
                <Smartphone className="h-4 w-4 text-emerald-400" />
                Pack APK via PWABuilder
              </a>
            </div>
            <p className="text-[11px] text-slate-400">
              Catatan: Server ini tidak memiliki Android SDK/Gradle sehingga file <span className="font-mono text-slate-200">.apk</span> biner tidak dapat dikompilasi di sini. Gunakan <span className="text-slate-200">PWABuilder</span> (untuk URL publik), <span className="text-slate-200">Chrome → Install App</span>, atau build <span className="font-mono text-slate-200">.zip</span> lewat GitHub Actions.
            </p>
          </div>
        </section>
      </div>

      {/* Sync Module Bug-Fix Audit */}
      <section className="rounded-2xl border border-white/10 bg-[#13151B] p-4 sm:p-5">
        <div className="flex items-center gap-2">
          <Wrench className="h-4 w-4 text-amber-400" />
          <h3 className="text-sm font-semibold text-white">
            Perbaikan Modul Sinkronisasi Audio (C++ Oboe & Kotlin)
          </h3>
        </div>

        <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-3">
          {SYNC_FIXES.map((fix) => (
            <div
              key={fix.id}
              className="rounded-xl border border-white/8 bg-[#0B0C10] p-3.5"
            >
              <div className="flex items-center justify-between gap-2 text-xs">
                <span className="font-mono text-emerald-400">{fix.file}</span>
                <span className="font-semibold text-amber-300">{fix.severity}</span>
              </div>
              <h4 className="mt-1.5 text-sm font-semibold text-white">{fix.title}</h4>
              <p className="mt-1 text-xs text-slate-400">{fix.cause}</p>
              <p className="mt-1.5 text-xs text-slate-200">{fix.resolution}</p>
            </div>
          ))}
        </div>

        {/* Fixed Native Code Preview */}
        <div className="mt-4">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
            <div className="flex items-center gap-2 text-xs font-medium text-slate-300">
              <Code2 className="h-4 w-4 text-sky-400" />
              <span>Source Code Native yang Telah Diperbaiki</span>
            </div>
            <div className="flex gap-1 rounded-xl bg-[#0B0C10] p-1">
              <button
                type="button"
                onClick={() => setActiveCodeTab('ringbuffer')}
                className={`min-h-[36px] rounded-lg px-3 text-xs font-medium transition-colors ${
                  activeCodeTab === 'ringbuffer' ? 'bg-white/15 text-white' : 'text-slate-400'
                }`}
              >
                LockFreeRingBuffer.h
              </button>
              <button
                type="button"
                onClick={() => setActiveCodeTab('mixer')}
                className={`min-h-[36px] rounded-lg px-3 text-xs font-medium transition-colors ${
                  activeCodeTab === 'mixer' ? 'bg-white/15 text-white' : 'text-slate-400'
                }`}
              >
                MixerEngine.cpp
              </button>
              <button
                type="button"
                onClick={() => setActiveCodeTab('manifest')}
                className={`min-h-[36px] rounded-lg px-3 text-xs font-medium transition-colors ${
                  activeCodeTab === 'manifest' ? 'bg-white/15 text-white' : 'text-slate-400'
                }`}
              >
                AndroidManifest.xml
              </button>
            </div>
          </div>

          <pre className="max-h-72 overflow-auto rounded-xl border border-white/10 bg-[#07080A] p-3.5 font-mono text-[11px] leading-relaxed text-slate-300">
            <code>{codeContent}</code>
          </pre>
        </div>
      </section>

      {showIosModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
          <div className="w-full max-w-sm rounded-2xl border border-white/10 bg-[#13151B] p-5">
            <h3 className="text-base font-semibold text-white">Install di iPhone / iPad</h3>
            <p className="mt-2 text-sm text-slate-300">
              1. Ketuk tombol <strong>Share</strong> di bilah Safari.<br />
              2. Gulir ke bawah dan pilih <strong>Add to Home Screen</strong>.
            </p>
            <button
              type="button"
              onClick={() => setShowIosModal(false)}
              className="mt-4 min-h-[44px] w-full rounded-xl bg-emerald-500 text-sm font-semibold text-slate-950"
            >
              Tutup
            </button>
          </div>
        </div>
      )}

      {showAndroidGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
          <div className="w-full max-w-md rounded-2xl border border-white/10 bg-[#13151B] p-5">
            <h3 className="text-base font-semibold text-white">Cara Mendapatkan / Install APK Android</h3>
            <div className="mt-3 flex flex-col gap-2.5 text-xs leading-relaxed text-slate-300">
              <p>
                <strong>1. Install Instan di Chrome Android (WebAPK):</strong> Buka URL aplikasi di tab baru Chrome Android (bukan di dalam preview iframe), lalu ketuk menu <strong>⋮ → Install app / Tambahkan ke layar utama</strong>.
              </p>
              <p>
                <strong>2. File .APK via GitHub Actions:</strong> Unduh <strong>Source Project (.zip)</strong>, upload ke GitHub, dan jalankan workflow <strong>build-apk</strong>. File <span className="font-mono text-emerald-400">AudioMaster-Pro-debug.apk</span> muncul di bagian <strong>Artifacts</strong> setelah status build hijau.
              </p>
              <p>
                <strong>3. File .APK via PWABuilder:</strong> Publikasikan/Share aplikasi terlebih dahulu, lalu klik <strong>Pack APK via PWABuilder</strong> untuk mengunduh paket <span className="font-mono text-emerald-400">.apk</span> Android siap instal.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowAndroidGuide(false)}
              className="mt-4 min-h-[44px] w-full rounded-xl bg-emerald-500 text-sm font-semibold text-slate-950"
            >
              Mengerti
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
