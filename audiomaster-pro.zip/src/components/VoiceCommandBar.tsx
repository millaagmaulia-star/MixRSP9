import React, { useState } from 'react';
import { Mic, MicOff, Send, ShieldCheck } from 'lucide-react';
import { VoiceCommandHistoryItem } from '../hooks/useVoiceCommands';

const QUICK_COMMANDS = [
  'Increase compression',
  'Set harmony to third',
  'Set harmony to fifth',
  'Key to G',
  'Increase delay',
  'Boost treble',
];

interface VoiceCommandBarProps {
  isSupported: boolean;
  isListening: boolean;
  requireWakeWord: boolean;
  language: 'en-US' | 'id-ID';
  interimTranscript: string;
  lastError: string | null;
  isProcessingAi: boolean;
  history: VoiceCommandHistoryItem[];
  onToggleListening: () => void;
  onToggleWakeWord: () => void;
  onChangeLanguage: (lang: 'en-US' | 'id-ID') => void;
  onSubmitManualCommand: (text: string) => void;
}

export const VoiceCommandBar: React.FC<VoiceCommandBarProps> = ({
  isSupported,
  isListening,
  requireWakeWord,
  language,
  interimTranscript,
  lastError,
  isProcessingAi,
  history,
  onToggleListening,
  onToggleWakeWord,
  onChangeLanguage,
  onSubmitManualCommand,
}) => {
  const [manualInput, setManualInput] = useState('');

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualInput.trim()) return;
    onSubmitManualCommand(manualInput.trim());
    setManualInput('');
  };

  return (
    <section className="rounded-2xl border border-white/10 bg-[#13151B] p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-sm font-semibold text-white">
            Hands-Free Voice Command Listener
          </h3>
          <p className="text-xs text-slate-400">
            Ucapkan <span className="text-slate-200">"increase compression"</span> atau{' '}
            <span className="text-slate-200">"set harmony to third"</span> saat tampil
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            value={language}
            onChange={(e) => onChangeLanguage(e.target.value as 'en-US' | 'id-ID')}
            aria-label="Bahasa pengenalan suara"
            className="min-h-[44px] rounded-xl border border-white/10 bg-[#0B0C10] px-3 text-xs font-medium text-slate-200 focus:border-emerald-500 focus:outline-none"
          >
            <option value="en-US">EN (US)</option>
            <option value="id-ID">ID (Indonesia)</option>
          </select>

          <button
            type="button"
            onClick={onToggleWakeWord}
            className={`min-h-[44px] inline-flex items-center gap-1.5 rounded-xl border px-3 text-xs font-medium transition-colors whitespace-nowrap ${
              requireWakeWord
                ? 'border-amber-500/50 bg-amber-500/15 text-amber-300'
                : 'border-white/10 bg-white/5 text-slate-300 hover:bg-white/10'
            }`}
          >
            <ShieldCheck className="h-4 w-4" />
            {requireWakeWord ? 'Wake: "AudioMaster"' : 'Mode Langsung'}
          </button>

          <button
            type="button"
            onClick={onToggleListening}
            className={`min-h-[44px] inline-flex items-center gap-2 rounded-xl px-4 text-xs font-semibold transition-colors whitespace-nowrap ${
              isListening
                ? 'bg-emerald-500 text-slate-950'
                : 'border border-emerald-500/40 bg-emerald-500/15 text-emerald-300 hover:bg-emerald-500/25'
            }`}
          >
            {isListening ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
            {isListening ? 'Mendengarkan...' : 'Aktifkan Voice'}
          </button>
        </div>
      </div>

      {/* Live Transcript / Status Line */}
      {(isListening || interimTranscript || isProcessingAi || lastError || !isSupported) && (
        <div className="mt-3 rounded-xl border border-white/8 bg-[#0B0C10] px-3.5 py-2.5 text-xs">
          {!isSupported && (
            <p className="text-amber-300">
              Web Speech API tidak tersedia di browser ini. Gunakan uji perintah teks atau tombol cepat di bawah.
            </p>
          )}
          {isListening && (
            <p className="text-slate-300">
              <span className="font-semibold text-emerald-400">Live Mic: </span>
              {interimTranscript ||
                (requireWakeWord
                  ? 'Sebut "AudioMaster..." diikuti perintah DSP'
                  : 'Menunggu perintah suara (mis. "increase compression")...')}
            </p>
          )}
          {isProcessingAi && (
            <p className="mt-1 text-sky-400">Memetakan perintah natural dengan AI...</p>
          )}
          {lastError && (
            <p className="mt-1 text-rose-400" role="alert">
              {lastError}
            </p>
          )}
        </div>
      )}

      {/* Quick Interactive Test / Fallback Command Strip */}
      <div className="mt-3 flex flex-col gap-2.5">
        <div className="flex flex-wrap gap-1.5">
          {QUICK_COMMANDS.map((cmd) => (
            <button
              key={cmd}
              type="button"
              onClick={() =>
                onSubmitManualCommand(requireWakeWord ? `AudioMaster ${cmd}` : cmd)
              }
              className="min-h-[36px] rounded-lg border border-white/10 bg-[#0B0C10] px-2.5 text-[11px] font-medium text-slate-300 transition-colors hover:border-emerald-500/50 hover:text-white whitespace-nowrap"
            >
              "{cmd}"
            </button>
          ))}
        </div>

        <form onSubmit={handleManualSubmit} className="flex gap-2">
          <input
            type="text"
            value={manualInput}
            onChange={(e) => setManualInput(e.target.value)}
            placeholder="Ketik atau uji perintah suara (mis. set harmony to fifth)..."
            className="min-h-[44px] flex-1 rounded-xl border border-white/10 bg-[#0B0C10] px-3.5 text-xs text-white placeholder:text-slate-500 focus:border-emerald-500 focus:outline-none"
          />
          <button
            type="submit"
            aria-label="Kirim perintah suara"
            className="min-h-[44px] min-w-[44px] inline-flex items-center justify-center rounded-xl border border-white/10 bg-white/5 px-3.5 text-xs font-semibold text-white hover:bg-white/10"
          >
            <Send className="h-4 w-4" />
          </button>
        </form>
      </div>

      {/* Recent Executed Voice Commands */}
      {history.length > 0 && (
        <div className="mt-3 flex flex-col divide-y divide-white/8 border-t border-white/8 pt-2">
          {history.slice(0, 3).map((item) => (
            <div
              key={item.id}
              className="flex items-center justify-between gap-3 py-1.5 text-xs"
            >
              <div className="min-w-0 flex-1">
                <span className="font-medium text-white">"{item.transcript}"</span>
                <span className="mx-1.5 text-slate-500" aria-hidden="true">
                  →
                </span>
                <span className="text-emerald-400">{item.summary}</span>
              </div>
              <span className="shrink-0 font-mono text-[11px] tabular-nums text-slate-500">
                {item.source === 'ai' ? 'AI' : 'DSP'} · {item.timestamp}
              </span>
            </div>
          ))}
        </div>
      )}
    </section>
  );
};
