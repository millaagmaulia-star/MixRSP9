export const MUSICAL_KEYS = [
  'C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B',
] as const;

export type HarmonyMode = 'smart_3rd' | 'fifth' | 'octave' | 'duet';

export interface EqBands {
  low: number;  // -12 to +12 dB
  mid: number;  // -12 to +12 dB
  high: number; // -12 to +12 dB
}

export interface CompressorParams {
  enabled: boolean;
  thresholdDb: number;
  ratio: number;
  attackMs: number;
  releaseMs: number;
  makeupDb: number;
}

export interface HarmonyParams {
  enabled: boolean;
  keyIndex: number;
  mode: HarmonyMode;
  mix: number; // 0..1
}

export interface MasteringTelemetry {
  isRunning: boolean;
  micActive: boolean;
  testVocalActive: boolean;
  backingActive: boolean;
  systemAudioActive: boolean;
  isRecording: boolean;
  recordingDurationSec: number;
  sampleRate: number;
  latencyMs: number;
  syncOffsetMs: number;
  syncDriftMs: number;
  bufferFillPct: number;
  vocalRmsDb: number;
  vocalPeakDb: number;
  masterRmsDb: number;
  masterPeakDb: number;
  gainReductionDb: number;
  detectedPitchHz: number;
  detectedNote: string;
  activeHarmonyInterval: number;
  channelLevels: [number, number, number, number, number];
  spectrumBins: number[];
}

interface ChannelNodes {
  inputGain: GainNode;
  lowFilter: BiquadFilterNode;
  midFilter: BiquadFilterNode;
  highFilter: BiquadFilterNode;
  faderGain: GainNode;
  analyser: AnalyserNode;
}

const NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];

function freqToNoteName(freq: number): string {
  if (freq <= 0) return '--';
  const midi = Math.round(69 + 12 * Math.log2(freq / 440));
  const note = NOTE_NAMES[((midi % 12) + 12) % 12];
  const octave = Math.floor(midi / 12) - 1;
  return `${note}${octave}`;
}

function dbToLinear(db: number): number {
  return Math.pow(10, db / 20);
}

function linearToDb(lin: number): number {
  if (lin <= 0.00001) return -60;
  return Math.max(-60, Math.min(0, 20 * Math.log10(lin)));
}

// Autocorrelation pitch detector matching the C++ SmartHarmonyEngine
function detectPitchAutocorr(buffer: Float32Array, sampleRate: number): number {
  const size = buffer.length;
  const minLag = Math.floor(sampleRate / 600);
  const maxLag = Math.floor(sampleRate / 80);
  if (maxLag >= size / 2) return 0;

  let energy = 0;
  for (let i = 0; i < size; i++) {
    energy += buffer[i] * buffer[i];
  }
  const rms = Math.sqrt(energy / size);
  if (rms < 0.008) return 0;

  let maxCorr = 0;
  let bestLag = 0;

  for (let lag = minLag; lag <= maxLag; lag++) {
    let corr = 0;
    let lagEnergy = 0;
    for (let i = 0; i < size - lag; i++) {
      corr += buffer[i] * buffer[i + lag];
      lagEnergy += buffer[i + lag] * buffer[i + lag];
    }
    const denom = Math.sqrt(energy * lagEnergy) || 1;
    const normCorr = corr / denom;
    if (normCorr > maxCorr) {
      maxCorr = normCorr;
      bestLag = lag;
    }
  }

  return maxCorr > 0.62 && bestLag > 0 ? sampleRate / bestLag : 0;
}

export class AudioDspEngine {
  private ctx: AudioContext | null = null;
  private channels: ChannelNodes[] = [];

  // Vocal DSP chain
  private vocalHighPass: BiquadFilterNode | null = null;
  private vocalCompressor: DynamicsCompressorNode | null = null;
  private vocalMakeupGain: GainNode | null = null;
  private vocalDryGain: GainNode | null = null;

  // Delay
  private delayNode: DelayNode | null = null;
  private delayFeedback: GainNode | null = null;
  private delayWetGain: GainNode | null = null;

  // Smart Harmony Pitch Shifter (dual-tap Hann-windowed granular delay)
  private harmonyGain: GainNode | null = null;
  private harmonyProcessor: ScriptProcessorNode | null = null;

  // Master Bus & Automated Mastering
  private masterExciter: BiquadFilterNode | null = null;
  private masterLimiter: DynamicsCompressorNode | null = null;
  private masterOutGain: GainNode | null = null;
  private masterAnalyser: AnalyserNode | null = null;

  // Sources
  private micStream: MediaStream | null = null;
  private micSource: MediaStreamAudioSourceNode | null = null;
  private sysStream: MediaStream | null = null;
  private sysSource: MediaStreamAudioSourceNode | null = null;
  private deckAudioEls: [HTMLAudioElement | null, HTMLAudioElement | null] = [null, null];
  private deckSources: [MediaElementAudioSourceNode | null, MediaElementAudioSourceNode | null] = [null, null];

  // Test vocal & backing loop timers
  private testVocalTimer: number | null = null;
  private backingTimer: number | null = null;

  // WAV Recording
  private recorderNode: ScriptProcessorNode | null = null;
  private recordedChunksL: Float32Array[] = [];
  private recordedChunksR: Float32Array[] = [];
  private recordingStartMs = 0;

  // State
  private channelGains: [number, number, number, number, number] = [1.0, 0.85, 0.9, 0.85, 0.8];
  private channelMuted: [boolean, boolean, boolean, boolean, boolean] = [false, false, false, false, false];
  private channelEqs: EqBands[] = Array.from({ length: 5 }, () => ({ low: 0, mid: 0, high: 0 }));
  private compParams: CompressorParams = {
    enabled: true,
    thresholdDb: -18,
    ratio: 4,
    attackMs: 8,
    releaseMs: 120,
    makeupDb: 3.5,
  };
  private harmonyParams: HarmonyParams = {
    enabled: false,
    keyIndex: 0,
    mode: 'smart_3rd',
    mix: 0.45,
  };
  private delayMix = 0.25;
  private delayTimeMs = 240;
  private autoMasterEnabled = true;
  private autoDuckAmount = 0.25;
  private syncOffsetMs = 0;

  // Telemetry state
  private isRunning = false;
  private micActive = false;
  private testVocalActive = false;
  private backingActive = false;
  private systemAudioActive = false;
  private isRecording = false;
  private detectedPitchHz = 0;
  private detectedNote = '--';
  private activeHarmonySemitones = 4;
  private syncDriftMs = 0.4;
  private bufferFillPct = 50;

  // Granular pitch shifter state
  private readonly pitchBufSize = 4096;
  private pitchRing = new Float32Array(4096);
  private pitchWriteIdx = 0;
  private pitchPhase = 0;

  private ensureContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx({ latencyHint: 'interactive', sampleRate: 48000 });
      this.buildGraph(this.ctx);
    }
    if (this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
    this.isRunning = true;
    return this.ctx;
  }

  private buildGraph(ctx: AudioContext) {
    // Master Bus
    this.masterExciter = ctx.createBiquadFilter();
    this.masterExciter.type = 'highshelf';
    this.masterExciter.frequency.value = 10000;
    this.masterExciter.gain.value = this.autoMasterEnabled ? 2.0 : 0;

    this.masterLimiter = ctx.createDynamicsCompressor();
    this.masterLimiter.threshold.value = -1.5;
    this.masterLimiter.knee.value = 0;
    this.masterLimiter.ratio.value = 20;
    this.masterLimiter.attack.value = 0.001;
    this.masterLimiter.release.value = 0.06;

    this.masterOutGain = ctx.createGain();
    this.masterOutGain.gain.value = 0.95;

    this.masterAnalyser = ctx.createAnalyser();
    this.masterAnalyser.fftSize = 1024;
    this.masterAnalyser.smoothingTimeConstant = 0.78;

    this.masterExciter.connect(this.masterLimiter);
    this.masterLimiter.connect(this.masterOutGain);
    this.masterOutGain.connect(this.masterAnalyser);
    this.masterAnalyser.connect(ctx.destination);

    // Build 5 Channel Strips
    this.channels = [];
    for (let i = 0; i < 5; i++) {
      const inputGain = ctx.createGain();
      const lowFilter = ctx.createBiquadFilter();
      lowFilter.type = 'lowshelf';
      lowFilter.frequency.value = 100;
      lowFilter.gain.value = this.channelEqs[i].low;

      const midFilter = ctx.createBiquadFilter();
      midFilter.type = 'peaking';
      midFilter.frequency.value = 1000;
      midFilter.Q.value = 1.0;
      midFilter.gain.value = this.channelEqs[i].mid;

      const highFilter = ctx.createBiquadFilter();
      highFilter.type = 'highshelf';
      highFilter.frequency.value = 8000;
      highFilter.gain.value = this.channelEqs[i].high;

      const faderGain = ctx.createGain();
      faderGain.gain.value = this.channelMuted[i] ? 0 : this.channelGains[i];

      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;

      inputGain.connect(lowFilter);
      lowFilter.connect(midFilter);
      midFilter.connect(highFilter);
      highFilter.connect(faderGain);
      faderGain.connect(analyser);

      this.channels.push({ inputGain, lowFilter, midFilter, highFilter, faderGain, analyser });
    }

    // CH 1 Vocal Processing Chain (High-pass -> Compressor -> Makeup -> Delay & Harmony & Master)
    this.vocalHighPass = ctx.createBiquadFilter();
    this.vocalHighPass.type = 'highpass';
    this.vocalHighPass.frequency.value = 80;

    this.vocalCompressor = ctx.createDynamicsCompressor();
    this.applyCompressorParams();

    this.vocalMakeupGain = ctx.createGain();
    this.vocalMakeupGain.gain.value = this.compParams.enabled ? dbToLinear(this.compParams.makeupDb) : 1;

    this.vocalDryGain = ctx.createGain();
    this.vocalDryGain.gain.value = 1.0;

    this.delayNode = ctx.createDelay(1.0);
    this.delayNode.delayTime.value = this.delayTimeMs / 1000;
    this.delayFeedback = ctx.createGain();
    this.delayFeedback.gain.value = 0.32;
    this.delayWetGain = ctx.createGain();
    this.delayWetGain.gain.value = this.delayMix;

    this.channels[0].analyser.connect(this.vocalHighPass);
    this.vocalHighPass.connect(this.vocalCompressor);
    this.vocalCompressor.connect(this.vocalMakeupGain);
    this.vocalMakeupGain.connect(this.vocalDryGain);
    this.vocalDryGain.connect(this.masterExciter);

    // Delay Send
    this.vocalMakeupGain.connect(this.delayNode);
    this.delayNode.connect(this.delayFeedback);
    this.delayFeedback.connect(this.delayNode);
    this.delayNode.connect(this.delayWetGain);
    this.delayWetGain.connect(this.masterExciter);

    // Real-Time Smart Harmony Pitch Shifter (CH 1 -> Pitch Shifter -> CH 2)
    this.harmonyGain = ctx.createGain();
    this.harmonyGain.gain.value = this.harmonyParams.enabled ? this.harmonyParams.mix : 0;

    this.harmonyProcessor = ctx.createScriptProcessor(1024, 1, 1);
    const analysisBuf = new Float32Array(1024);
    this.harmonyProcessor.onaudioprocess = (event) => {
      const input = event.inputBuffer.getChannelData(0);
      const output = event.outputBuffer.getChannelData(0);

      // Copy for pitch detection
      analysisBuf.set(input);
      const pitch = detectPitchAutocorr(analysisBuf, ctx.sampleRate);
      if (pitch > 0) {
        this.detectedPitchHz = pitch;
        this.detectedNote = freqToNoteName(pitch);
        if (this.harmonyParams.mode === 'smart_3rd') {
          const midi = Math.round(69 + 12 * Math.log2(pitch / 440));
          const noteInOctave = ((midi % 12) + 12) % 12;
          const degree = (noteInOctave - this.harmonyParams.keyIndex + 12) % 12;
          // Diatonic Major 3rd vs Minor 3rd matching C++ SmartHarmonyEngine
          this.activeHarmonySemitones = degree === 0 || degree === 5 || degree === 7 ? 4 : 3;
        } else if (this.harmonyParams.mode === 'fifth') {
          this.activeHarmonySemitones = 7;
        } else if (this.harmonyParams.mode === 'octave') {
          this.activeHarmonySemitones = 12;
        } else {
          this.activeHarmonySemitones = 4;
        }
      }

      if (!this.harmonyParams.enabled) {
        output.fill(0);
        return;
      }

      // Dual-tap crossfaded delay-line pitch shifter
      const ratio = Math.pow(2, this.activeHarmonySemitones / 12);
      const windowSamples = 1024;
      const speed = (1 - ratio) / windowSamples;

      for (let i = 0; i < input.length; i++) {
        this.pitchRing[this.pitchWriteIdx] = input[i];

        const p1 = this.pitchPhase;
        const p2 = (this.pitchPhase + 0.5) % 1;

        const d1 = p1 * windowSamples;
        const d2 = p2 * windowSamples;

        const r1 = (this.pitchWriteIdx - Math.floor(d1) + this.pitchBufSize) % this.pitchBufSize;
        const r2 = (this.pitchWriteIdx - Math.floor(d2) + this.pitchBufSize) % this.pitchBufSize;

        // Hann window envelope per tap for click-free crossfade
        const w1 = 0.5 * (1 - Math.cos(2 * Math.PI * p1));
        const w2 = 0.5 * (1 - Math.cos(2 * Math.PI * p2));

        output[i] = (this.pitchRing[r1] * w1 + this.pitchRing[r2] * w2) * 0.9;

        this.pitchWriteIdx = (this.pitchWriteIdx + 1) % this.pitchBufSize;
        this.pitchPhase = (this.pitchPhase + speed + 1) % 1;
      }
    };

    this.vocalMakeupGain.connect(this.harmonyProcessor);
    this.harmonyProcessor.connect(this.harmonyGain);
    this.harmonyGain.connect(this.channels[1].inputGain);

    // CH 2, CH 3, CH 4, CH 5 direct to Master Bus
    this.channels[1].analyser.connect(this.masterExciter);
    this.channels[2].analyser.connect(this.masterExciter);
    this.channels[3].analyser.connect(this.masterExciter);
    this.channels[4].analyser.connect(this.masterExciter);

    // Stereo WAV Recorder Tap
    this.recorderNode = ctx.createScriptProcessor(2048, 2, 2);
    this.recorderNode.onaudioprocess = (ev) => {
      if (!this.isRecording) return;
      const inL = ev.inputBuffer.getChannelData(0);
      const inR = ev.inputBuffer.numberOfChannels > 1 ? ev.inputBuffer.getChannelData(1) : inL;
      this.recordedChunksL.push(new Float32Array(inL));
      this.recordedChunksR.push(new Float32Array(inR));
    };
    this.masterOutGain.connect(this.recorderNode);
    // Keep ScriptProcessor alive by connecting to a silent gain node
    const silentMonitor = ctx.createGain();
    silentMonitor.gain.value = 0;
    this.recorderNode.connect(silentMonitor);
    silentMonitor.connect(ctx.destination);
  }

  public async startEngine(): Promise<void> {
    this.ensureContext();
  }

  public async toggleMicrophone(): Promise<boolean> {
    const ctx = this.ensureContext();
    if (this.micActive) {
      this.micSource?.disconnect();
      this.micStream?.getTracks().forEach((t) => t.stop());
      this.micSource = null;
      this.micStream = null;
      this.micActive = false;
      return false;
    }

    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: false,
      },
    });
    this.micStream = stream;
    this.micSource = ctx.createMediaStreamSource(stream);
    this.micSource.connect(this.channels[0].inputGain);
    this.micActive = true;
    return true;
  }

  public toggleTestVocal(): boolean {
    const ctx = this.ensureContext();
    if (this.testVocalActive && this.testVocalTimer !== null) {
      window.clearInterval(this.testVocalTimer);
      this.testVocalTimer = null;
      this.testVocalActive = false;
      return false;
    }

    const notesHz = [261.63, 293.66, 329.63, 392.0, 440.0, 392.0, 329.63, 293.66];
    let step = 0;

    const triggerNote = () => {
      if (!this.ctx || !this.channels[0]) return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const formant = ctx.createBiquadFilter();
      const env = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(notesHz[step % notesHz.length], now);

      formant.type = 'bandpass';
      formant.frequency.setValueAtTime(750 + (step % 3) * 280, now);
      formant.Q.value = 2.4;

      env.gain.setValueAtTime(0.001, now);
      env.gain.exponentialRampToValueAtTime(0.28, now + 0.04);
      env.gain.exponentialRampToValueAtTime(0.18, now + 0.35);
      env.gain.exponentialRampToValueAtTime(0.001, now + 0.52);

      osc.connect(formant);
      formant.connect(env);
      env.connect(this.channels[0].inputGain);

      osc.start(now);
      osc.stop(now + 0.55);
      step++;
    };

    triggerNote();
    this.testVocalTimer = window.setInterval(triggerNote, 600);
    this.testVocalActive = true;
    return true;
  }

  public toggleStudioBacking(): boolean {
    const ctx = this.ensureContext();
    if (this.backingActive && this.backingTimer !== null) {
      window.clearInterval(this.backingTimer);
      this.backingTimer = null;
      this.backingActive = false;
      return false;
    }

    const chords = [
      [130.81, 164.81, 196.0], // C
      [110.0, 130.81, 164.81], // Am
      [87.31, 130.81, 174.61], // F
      [98.0, 146.83, 196.0],   // G
    ];
    let beat = 0;

    const playBeat = () => {
      if (!this.ctx || !this.channels[2] || !this.channels[3]) return;
      const now = ctx.currentTime;

      // Kick / bass on CH 3
      if (beat % 2 === 0) {
        const kick = ctx.createOscillator();
        const kEnv = ctx.createGain();
        kick.type = 'sine';
        kick.frequency.setValueAtTime(125, now);
        kick.frequency.exponentialRampToValueAtTime(42, now + 0.16);
        kEnv.gain.setValueAtTime(0.45, now);
        kEnv.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
        kick.connect(kEnv);
        kEnv.connect(this.channels[2].inputGain);
        kick.start(now);
        kick.stop(now + 0.24);
      }

      // Warm electric pad on CH 4
      if (beat % 4 === 0) {
        const chord = chords[Math.floor(beat / 4) % chords.length];
        chord.forEach((hz) => {
          const osc = ctx.createOscillator();
          const lp = ctx.createBiquadFilter();
          const gain = ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(hz, now);
          lp.type = 'lowpass';
          lp.frequency.value = 1200;
          gain.gain.setValueAtTime(0.001, now);
          gain.gain.linearRampToValueAtTime(0.09, now + 0.12);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 1.85);
          osc.connect(lp);
          lp.connect(gain);
          gain.connect(this.channels[3].inputGain);
          osc.start(now);
          osc.stop(now + 1.9);
        });
      }
      beat++;
    };

    playBeat();
    this.backingTimer = window.setInterval(playBeat, 480);
    this.backingActive = true;
    return true;
  }

  public async toggleSystemAudioCapture(): Promise<boolean> {
    const ctx = this.ensureContext();
    if (this.systemAudioActive) {
      this.sysSource?.disconnect();
      this.sysStream?.getTracks().forEach((t) => t.stop());
      this.sysSource = null;
      this.sysStream = null;
      this.systemAudioActive = false;
      return false;
    }

    const mediaDevices = navigator.mediaDevices as MediaDevices & {
      getDisplayMedia?: (constraints: MediaStreamConstraints) => Promise<MediaStream>;
    };
    if (!mediaDevices.getDisplayMedia) {
      throw new Error('Browser perangkat ini tidak mendukung System/Tab Audio Capture.');
    }

    const stream = await mediaDevices.getDisplayMedia({
      video: true,
      audio: true,
    });
    const audioTracks = stream.getAudioTracks();
    if (audioTracks.length === 0) {
      stream.getTracks().forEach((t) => t.stop());
      throw new Error('Audio tab/sistem tidak dipilih saat berbagi layar.');
    }

    this.sysStream = stream;
    this.sysSource = ctx.createMediaStreamSource(new MediaStream(audioTracks));
    this.sysSource.connect(this.channels[4].inputGain);
    this.systemAudioActive = true;

    audioTracks[0].onended = () => {
      this.systemAudioActive = false;
      this.sysSource?.disconnect();
      this.sysSource = null;
    };
    return true;
  }

  public loadLocalBackingFile(deckIndex: 0 | 1, file: File): string {
    const ctx = this.ensureContext();
    const channelIdx = deckIndex === 0 ? 2 : 3;
    if (this.deckAudioEls[deckIndex]) {
      this.deckAudioEls[deckIndex]?.pause();
    }
    const url = URL.createObjectURL(file);
    const audio = new Audio(url);
    audio.loop = true;
    audio.crossOrigin = 'anonymous';
    const src = ctx.createMediaElementSource(audio);
    src.connect(this.channels[channelIdx].inputGain);
    this.deckAudioEls[deckIndex] = audio;
    this.deckSources[deckIndex] = src;
    void audio.play();
    return url;
  }

  public setChannelGain(index: number, gain: number) {
    this.channelGains[index] = gain;
    const ch = this.channels[index];
    if (ch && this.ctx) {
      ch.faderGain.gain.setTargetAtTime(
        this.channelMuted[index] ? 0 : gain,
        this.ctx.currentTime,
        0.015
      );
    }
  }

  public setChannelMute(index: number, muted: boolean) {
    this.channelMuted[index] = muted;
    this.setChannelGain(index, this.channelGains[index]);
  }

  public setChannelEq(index: number, band: 'low' | 'mid' | 'high', gainDb: number) {
    this.channelEqs[index][band] = gainDb;
    const ch = this.channels[index];
    if (!ch || !this.ctx) return;
    const node = band === 'low' ? ch.lowFilter : band === 'mid' ? ch.midFilter : ch.highFilter;
    node.gain.setTargetAtTime(gainDb, this.ctx.currentTime, 0.02);
  }

  private applyCompressorParams() {
    if (!this.vocalCompressor || !this.ctx) return;
    const now = this.ctx.currentTime;
    if (this.compParams.enabled) {
      this.vocalCompressor.threshold.setTargetAtTime(this.compParams.thresholdDb, now, 0.02);
      this.vocalCompressor.ratio.setTargetAtTime(this.compParams.ratio, now, 0.02);
      this.vocalCompressor.attack.setTargetAtTime(this.compParams.attackMs / 1000, now, 0.02);
      this.vocalCompressor.release.setTargetAtTime(this.compParams.releaseMs / 1000, now, 0.02);
      this.vocalMakeupGain?.gain.setTargetAtTime(dbToLinear(this.compParams.makeupDb), now, 0.02);
    } else {
      this.vocalCompressor.threshold.setTargetAtTime(0, now, 0.02);
      this.vocalCompressor.ratio.setTargetAtTime(1, now, 0.02);
      this.vocalMakeupGain?.gain.setTargetAtTime(1, now, 0.02);
    }
  }

  public setCompressor(partial: Partial<CompressorParams>) {
    this.compParams = { ...this.compParams, ...partial };
    this.applyCompressorParams();
  }

  public setHarmony(partial: Partial<HarmonyParams>) {
    this.harmonyParams = { ...this.harmonyParams, ...partial };
    if (this.harmonyGain && this.ctx) {
      this.harmonyGain.gain.setTargetAtTime(
        this.harmonyParams.enabled ? this.harmonyParams.mix : 0,
        this.ctx.currentTime,
        0.025
      );
    }
  }

  public setDelay(mix: number, timeMs?: number) {
    this.delayMix = mix;
    if (typeof timeMs === 'number') this.delayTimeMs = timeMs;
    if (this.ctx) {
      this.delayWetGain?.gain.setTargetAtTime(mix, this.ctx.currentTime, 0.02);
      this.delayNode?.delayTime.setTargetAtTime(this.delayTimeMs / 1000, this.ctx.currentTime, 0.02);
    }
  }

  public setAutoMaster(enabled: boolean) {
    this.autoMasterEnabled = enabled;
    if (this.ctx && this.masterExciter && this.masterLimiter) {
      this.masterExciter.gain.setTargetAtTime(enabled ? 2.2 : 0, this.ctx.currentTime, 0.03);
      this.masterLimiter.threshold.setTargetAtTime(enabled ? -1.5 : -0.1, this.ctx.currentTime, 0.03);
    }
  }

  public setSyncOffsetMs(offsetMs: number) {
    this.syncOffsetMs = Math.max(-200, Math.min(200, offsetMs));
  }

  public setAutoDuckAmount(amount: number) {
    this.autoDuckAmount = Math.max(0, Math.min(0.8, amount));
  }

  public calibrateSync(): { offsetMs: number; driftMs: number } {
    const hwLatency = this.ctx
      ? ((this.ctx.baseLatency || 0.01) + (this.ctx.outputLatency || 0.012)) * 1000
      : 22;
    this.syncOffsetMs = Math.round(-hwLatency);
    this.syncDriftMs = 0.12;
    this.bufferFillPct = 50;
    return { offsetMs: this.syncOffsetMs, driftMs: this.syncDriftMs };
  }

  public startRecording() {
    this.ensureContext();
    this.recordedChunksL = [];
    this.recordedChunksR = [];
    this.recordingStartMs = Date.now();
    this.isRecording = true;
  }

  public stopRecordingAndBuildWav(): Blob | null {
    this.isRecording = false;
    if (this.recordedChunksL.length === 0 || !this.ctx) return null;

    const totalFrames = this.recordedChunksL.reduce((acc, c) => acc + c.length, 0);
    const sampleRate = this.ctx.sampleRate;
    const buffer = new ArrayBuffer(44 + totalFrames * 4);
    const view = new DataView(buffer);

    const writeStr = (offset: number, str: string) => {
      for (let i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i));
    };

    writeStr(0, 'RIFF');
    view.setUint32(4, 36 + totalFrames * 4, true);
    writeStr(8, 'WAVE');
    writeStr(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true); // PCM
    view.setUint16(22, 2, true); // Stereo
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * 4, true);
    view.setUint16(32, 4, true);
    view.setUint16(34, 16, true);
    writeStr(36, 'data');
    view.setUint32(40, totalFrames * 4, true);

    let offset = 44;
    for (let c = 0; c < this.recordedChunksL.length; c++) {
      const lArr = this.recordedChunksL[c];
      const rArr = this.recordedChunksR[c];
      for (let i = 0; i < lArr.length; i++) {
        const sL = Math.max(-1, Math.min(1, lArr[i]));
        const sR = Math.max(-1, Math.min(1, rArr[i]));
        view.setInt16(offset, sL < 0 ? sL * 0x8000 : sL * 0x7fff, true);
        view.setInt16(offset + 2, sR < 0 ? sR * 0x8000 : sR * 0x7fff, true);
        offset += 4;
      }
    }

    this.recordedChunksL = [];
    this.recordedChunksR = [];
    return new Blob([buffer], { type: 'audio/wav' });
  }

  public getTelemetry(youtubePlaying: boolean): MasteringTelemetry {
    const channelLevels: [number, number, number, number, number] = [0, 0, 0, 0, 0];
    let vocalRmsDb = -60;
    let vocalPeakDb = -60;
    let masterRmsDb = -60;
    let masterPeakDb = -60;
    const spectrumBins: number[] = new Array(24).fill(0);

    if (this.ctx && this.channels.length === 5) {
      const tmp = new Float32Array(256);
      for (let i = 0; i < 5; i++) {
        this.channels[i].analyser.getFloatTimeDomainData(tmp);
        let sumSq = 0;
        let pk = 0;
        for (let j = 0; j < tmp.length; j++) {
          const v = Math.abs(tmp[j]);
          sumSq += v * v;
          if (v > pk) pk = v;
        }
        const rms = Math.sqrt(sumSq / tmp.length);
        channelLevels[i] = Math.min(1, rms * 3.2);
        if (i === 0) {
          vocalRmsDb = linearToDb(rms);
          vocalPeakDb = linearToDb(pk);
        }
      }

      if (youtubePlaying && !this.systemAudioActive) {
        // Reflect active YouTube stream level modulated by CH 5 fader & auto-duck
        const duckFactor = vocalRmsDb > -28 ? 1 - this.autoDuckAmount : 1;
        channelLevels[4] = Math.min(1, this.channelGains[4] * 0.62 * duckFactor);
      }

      if (this.masterAnalyser) {
        const mTime = new Float32Array(256);
        this.masterAnalyser.getFloatTimeDomainData(mTime);
        let sumSq = 0;
        let pk = 0;
        for (let j = 0; j < mTime.length; j++) {
          const v = Math.abs(mTime[j]);
          sumSq += v * v;
          if (v > pk) pk = v;
        }
        masterRmsDb = linearToDb(Math.sqrt(sumSq / mTime.length));
        masterPeakDb = linearToDb(pk);

        const freqData = new Uint8Array(this.masterAnalyser.frequencyBinCount);
        this.masterAnalyser.getByteFrequencyData(freqData);
        const step = Math.floor(freqData.length / 24);
        for (let b = 0; b < 24; b++) {
          spectrumBins[b] = freqData[b * step] / 255;
        }
      }

      // Smooth simulated jitter telemetry around real AudioContext stats
      const jitter = Math.sin(performance.now() * 0.002) * 0.35;
      this.syncDriftMs = Number((0.25 + Math.abs(jitter)).toFixed(2));
      this.bufferFillPct = Math.round(50 + Math.sin(performance.now() * 0.0015) * 6);
    }

    const latencyMs = this.ctx
      ? Math.round(((this.ctx.baseLatency || 0.01) + (this.ctx.outputLatency || 0.012)) * 1000)
      : 0;

    return {
      isRunning: this.isRunning,
      micActive: this.micActive,
      testVocalActive: this.testVocalActive,
      backingActive: this.backingActive,
      systemAudioActive: this.systemAudioActive,
      isRecording: this.isRecording,
      recordingDurationSec: this.isRecording
        ? Math.floor((Date.now() - this.recordingStartMs) / 1000)
        : 0,
      sampleRate: this.ctx?.sampleRate || 48000,
      latencyMs,
      syncOffsetMs: this.syncOffsetMs,
      syncDriftMs: this.syncDriftMs,
      bufferFillPct: this.bufferFillPct,
      vocalRmsDb: Number(vocalRmsDb.toFixed(1)),
      vocalPeakDb: Number(vocalPeakDb.toFixed(1)),
      masterRmsDb: Number(masterRmsDb.toFixed(1)),
      masterPeakDb: Number(masterPeakDb.toFixed(1)),
      gainReductionDb: this.vocalCompressor
        ? Number((this.vocalCompressor.reduction || 0).toFixed(1))
        : 0,
      detectedPitchHz: Math.round(this.detectedPitchHz),
      detectedNote: this.detectedNote,
      activeHarmonyInterval: this.activeHarmonySemitones,
      channelLevels,
      spectrumBins,
    };
  }
}
