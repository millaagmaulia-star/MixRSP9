import { HarmonyMode, MUSICAL_KEYS } from './AudioDspEngine';

export interface VoiceDspAction {
  matched: boolean;
  actionSummary: string;
  compressorEnabled?: boolean;
  compressorThresholdDeltaDb?: number;
  compressorRatioDelta?: number;
  compressorMakeupDeltaDb?: number;
  harmonyEnabled?: boolean;
  harmonyMode?: HarmonyMode;
  harmonyKeyIndex?: number;
  harmonyMixDelta?: number;
  delayMixDelta?: number;
  delayMixAbsolute?: number;
  vocalEqLowDelta?: number;
  vocalEqMidDelta?: number;
  vocalEqHighDelta?: number;
  resetVocalEq?: boolean;
  autoMasterEnabled?: boolean;
  youtubeMuted?: boolean;
  youtubeGainDelta?: number;
  recordingAction?: 'start' | 'stop' | 'none';
}

const KEY_ALIASES: Array<{ pattern: RegExp; index: number }> = [
  { pattern: /\b(c\s*sharp|c#|cis)\b/i, index: 1 },
  { pattern: /\b(d\s*sharp|d#|dis|e\s*flat|eb)\b/i, index: 3 },
  { pattern: /\b(f\s*sharp|f#|fis)\b/i, index: 6 },
  { pattern: /\b(g\s*sharp|g#|gis|a\s*flat|ab)\b/i, index: 8 },
  { pattern: /\b(a\s*sharp|a#|ais|b\s*flat|bb)\b/i, index: 10 },
  { pattern: /\bkey\s+(?:to\s+)?c\b|\bkunci\s+c\b/i, index: 0 },
  { pattern: /\bkey\s+(?:to\s+)?d\b|\bkunci\s+d\b/i, index: 2 },
  { pattern: /\bkey\s+(?:to\s+)?e\b|\bkunci\s+e\b/i, index: 4 },
  { pattern: /\bkey\s+(?:to\s+)?f\b|\bkunci\s+f\b/i, index: 5 },
  { pattern: /\bkey\s+(?:to\s+)?g\b|\bkunci\s+g\b/i, index: 7 },
  { pattern: /\bkey\s+(?:to\s+)?a\b|\bkunci\s+a\b/i, index: 9 },
  { pattern: /\bkey\s+(?:to\s+)?b\b|\bkunci\s+b\b/i, index: 11 },
];

export function stripWakeWord(rawTranscript: string, requireWakeWord: boolean): string | null {
  const cleaned = rawTranscript.trim().toLowerCase();
  if (!cleaned) return null;

  const wakeRegex = /^(?:hey\s+)?(?:audio\s*master|audiomaster|studio|mixer)[,\s]+/i;
  if (requireWakeWord) {
    if (!wakeRegex.test(cleaned)) return null;
    return cleaned.replace(wakeRegex, '').trim();
  }
  return cleaned.replace(wakeRegex, '').trim();
}

export function parseLocalVoiceCommand(commandText: string): VoiceDspAction | null {
  const text = commandText.trim().toLowerCase();
  if (!text) return null;

  // 1. Compressor controls
  if (/(increase|more|raise|boost|up|tambah|naikkan)\s+(vocal\s+)?(compression|compressor|kompresi|kompresor)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Kompresi dinaikkan (Threshold -4 dB, Ratio +1)',
      compressorEnabled: true,
      compressorThresholdDeltaDb: -4,
      compressorRatioDelta: 1,
    };
  }
  if (/(decrease|less|reduce|lower|down|kurangi|turunkan)\s+(vocal\s+)?(compression|compressor|kompresi|kompresor)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Kompresi dikurangi (Threshold +4 dB, Ratio -1)',
      compressorThresholdDeltaDb: 4,
      compressorRatioDelta: -1,
    };
  }
  if (/(enable|turn on|activate|start|nyalakan|aktifkan)\s+(vocal\s+)?(compression|compressor|kompresi|kompresor)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Vocal Compressor diaktifkan',
      compressorEnabled: true,
    };
  }
  if (/(disable|turn off|bypass|stop|matikan|nonaktifkan)\s+(vocal\s+)?(compression|compressor|kompresi|kompresor)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Vocal Compressor dimatikan',
      compressorEnabled: false,
    };
  }
  if (/(increase|boost|more|tambah|naikkan)\s+(makeup|vocal\s*gain)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Makeup gain vokal +1.5 dB',
      compressorEnabled: true,
      compressorMakeupDeltaDb: 1.5,
    };
  }

  // 2. Smart Harmony controls
  if (/(set\s+harmony\s+(to\s+)?|harmony\s+(to\s+)?|harmoni\s+)(a\s+)?(third|3rd|tiga)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Smart Harmony diatur ke Diatonic 3rd',
      harmonyEnabled: true,
      harmonyMode: 'smart_3rd',
    };
  }
  if (/(set\s+harmony\s+(to\s+)?|harmony\s+(to\s+)?|harmoni\s+)(a\s+)?(fifth|5th|lima)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Smart Harmony diatur ke Perfect 5th (+7 st)',
      harmonyEnabled: true,
      harmonyMode: 'fifth',
    };
  }
  if (/(set\s+harmony\s+(to\s+)?|harmony\s+(to\s+)?|harmoni\s+)(an?\s+)?(octave|oktaf)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Smart Harmony diatur ke Octave (+12 st)',
      harmonyEnabled: true,
      harmonyMode: 'octave',
    };
  }
  if (/(set\s+harmony\s+(to\s+)?|harmony\s+(to\s+)?|harmoni\s+)(duet)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Smart Harmony diatur ke Major Duet (+4 st)',
      harmonyEnabled: true,
      harmonyMode: 'duet',
    };
  }
  if (/(enable|turn on|activate|start|nyalakan|aktifkan)\s+(smart\s+)?(harmony|harmoni)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Smart Harmony DSP diaktifkan',
      harmonyEnabled: true,
    };
  }
  if (/(disable|turn off|bypass|stop|matikan|nonaktifkan)\s+(smart\s+)?(harmony|harmoni)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Smart Harmony DSP dimatikan',
      harmonyEnabled: false,
    };
  }
  if (/(increase|more|raise|boost|tambah|naikkan)\s+(harmony|harmoni)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Level Smart Harmony +15%',
      harmonyEnabled: true,
      harmonyMixDelta: 0.15,
    };
  }
  if (/(decrease|less|reduce|lower|kurangi|turunkan)\s+(harmony|harmoni)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Level Smart Harmony -15%',
      harmonyMixDelta: -0.15,
    };
  }

  // Musical Key selection
  for (const entry of KEY_ALIASES) {
    if (entry.pattern.test(text)) {
      return {
        matched: true,
        actionSummary: `Kunci harmoni diatur ke ${MUSICAL_KEYS[entry.index]} Major`,
        harmonyEnabled: true,
        harmonyKeyIndex: entry.index,
      };
    }
  }

  // 3. Delay / Echo controls
  if (/(increase|more|raise|add|tambah|naikkan)\s+(delay|echo|gema)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Echo Delay dinaikkan +10%',
      delayMixDelta: 0.1,
    };
  }
  if (/(decrease|less|reduce|lower|kurangi|turunkan)\s+(delay|echo|gema)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Echo Delay dikurangi -10%',
      delayMixDelta: -0.1,
    };
  }
  if (/(disable|turn off|no|zero|matikan)\s+(delay|echo|gema)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Echo Delay dimatikan (0%)',
      delayMixAbsolute: 0,
    };
  }

  // 4. Vocal EQ controls
  if (/(boost|increase|more|tambah)\s+(bass|low)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Vocal EQ Low +3 dB',
      vocalEqLowDelta: 3,
    };
  }
  if (/(cut|decrease|less|reduce|kurangi)\s+(bass|low)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Vocal EQ Low -3 dB',
      vocalEqLowDelta: -3,
    };
  }
  if (/(boost|increase|more|tambah)\s+(treble|high|bright|brightness|clarity)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Vocal EQ High +3 dB',
      vocalEqHighDelta: 3,
    };
  }
  if (/(cut|decrease|less|reduce|kurangi)\s+(treble|high)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Vocal EQ High -3 dB',
      vocalEqHighDelta: -3,
    };
  }
  if (/(reset|flat)\s+(eq|equalizer)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Vocal EQ di-reset ke Flat (0 dB)',
      resetVocalEq: true,
    };
  }

  // 5. Auto-Master, Recording & YouTube channel
  if (/(enable|turn on|activate|nyalakan)\s+(auto\s*master|mastering)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Automated Vocal Mastering diaktifkan',
      autoMasterEnabled: true,
    };
  }
  if (/(disable|turn off|matikan)\s+(auto\s*master|mastering)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Automated Vocal Mastering dimatikan',
      autoMasterEnabled: false,
    };
  }
  if (/(start|mulai)\s+(recording|record|rekam|rekaman)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Memulai rekaman Stereo WAV',
      recordingAction: 'start',
    };
  }
  if (/(stop|berhenti|selesai)\s+(recording|record|rekam|rekaman)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Menghentikan rekaman Stereo WAV',
      recordingAction: 'stop',
    };
  }
  if (/(mute|bisukan)\s+(youtube|music|backing|musik)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Channel YouTube dibisukan',
      youtubeMuted: true,
    };
  }
  if (/(unmute|nyalakan)\s+(youtube|music|backing|musik)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Channel YouTube diaktifkan kembali',
      youtubeMuted: false,
    };
  }
  if (/(lower|decrease|quieter|kecilkan|turunkan)\s+(youtube|music|backing|musik)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Volume YouTube diturunkan -15%',
      youtubeGainDelta: -0.15,
    };
  }
  if (/(raise|increase|louder|besarkan|naikkan)\s+(youtube|music|backing|musik)/i.test(text)) {
    return {
      matched: true,
      actionSummary: 'Volume YouTube dinaikkan +15%',
      youtubeGainDelta: 0.15,
    };
  }

  return null;
}
