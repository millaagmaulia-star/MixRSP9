import { useCallback, useEffect, useRef, useState } from 'react';
import {
  VoiceDspAction,
  parseLocalVoiceCommand,
  stripWakeWord,
} from '../audio/voiceCommandParser';

interface SpeechRecognitionAlternativeLike {
  transcript: string;
  confidence: number;
}

interface SpeechRecognitionResultLike {
  isFinal: boolean;
  0: SpeechRecognitionAlternativeLike;
}

interface SpeechRecognitionEventLike extends Event {
  resultIndex: number;
  results: ArrayLike<SpeechRecognitionResultLike>;
}

interface SpeechRecognitionErrorEventLike extends Event {
  error: string;
}

interface SpeechRecognitionInstance extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onresult: ((ev: SpeechRecognitionEventLike) => void) | null;
  onerror: ((ev: SpeechRecognitionErrorEventLike) => void) | null;
  onend: (() => void) | null;
}

type SpeechRecognitionCtor = new () => SpeechRecognitionInstance;

export interface VoiceCommandHistoryItem {
  id: number;
  transcript: string;
  summary: string;
  source: 'local' | 'ai';
  timestamp: string;
}

interface UseVoiceCommandsOptions {
  onExecuteAction: (action: VoiceDspAction) => void;
}

export function useVoiceCommands({ onExecuteAction }: UseVoiceCommandsOptions) {
  const [isSupported, setIsSupported] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [requireWakeWord, setRequireWakeWord] = useState(false);
  const [language, setLanguage] = useState<'en-US' | 'id-ID'>('en-US');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [lastError, setLastError] = useState<string | null>(null);
  const [isProcessingAi, setIsProcessingAi] = useState(false);
  const [history, setHistory] = useState<VoiceCommandHistoryItem[]>([]);

  const recognitionRef = useRef<SpeechRecognitionInstance | null>(null);
  const shouldKeepListeningRef = useRef(false);
  const requireWakeWordRef = useRef(requireWakeWord);
  const onExecuteRef = useRef(onExecuteAction);

  requireWakeWordRef.current = requireWakeWord;
  onExecuteRef.current = onExecuteAction;

  useEffect(() => {
    const win = window as unknown as {
      SpeechRecognition?: SpeechRecognitionCtor;
      webkitSpeechRecognition?: SpeechRecognitionCtor;
    };
    setIsSupported(Boolean(win.SpeechRecognition || win.webkitSpeechRecognition));
  }, []);

  const recordHistory = useCallback(
    (transcript: string, summary: string, source: 'local' | 'ai') => {
      const now = new Date();
      const timestamp = now.toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
      setHistory((prev) => [
        { id: Date.now() + Math.random(), transcript, summary, source, timestamp },
        ...prev.slice(0, 5),
      ]);
    },
    []
  );

  const processTranscript = useCallback(
    async (rawTranscript: string) => {
      const command = stripWakeWord(rawTranscript, requireWakeWordRef.current);
      if (!command) return;

      // 1. Ultra-fast local deterministic keyword match (0ms latency)
      const localAction = parseLocalVoiceCommand(command);
      if (localAction && localAction.matched) {
        onExecuteRef.current(localAction);
        recordHistory(rawTranscript.trim(), localAction.actionSummary, 'local');
        setLastError(null);
        return;
      }

      // 2. Gemini AI natural-language fallback for complex vocal requests
      setIsProcessingAi(true);
      try {
        const res = await fetch('/api/ai/voice-command', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ transcript: command }),
        });
        const data = (await res.json()) as VoiceDspAction & { error?: string };
        if (!res.ok) {
          setLastError(data.error || 'Perintah suara tidak dikenali.');
          return;
        }
        if (data.matched) {
          onExecuteRef.current(data);
          recordHistory(rawTranscript.trim(), data.actionSummary, 'ai');
          setLastError(null);
        } else {
          setLastError(`Perintah "${rawTranscript.trim()}" belum dikenali.`);
        }
      } catch {
        setLastError('Gagal menghubungi parser AI untuk perintah suara.');
      } finally {
        setIsProcessingAi(false);
      }
    },
    [recordHistory]
  );

  const startListening = useCallback(() => {
    const win = window as unknown as {
      SpeechRecognition?: SpeechRecognitionCtor;
      webkitSpeechRecognition?: SpeechRecognitionCtor;
    };
    const Ctor = win.SpeechRecognition || win.webkitSpeechRecognition;
    if (!Ctor) {
      setLastError('Browser ini belum mendukung Web Speech API. Gunakan input teks cepat di bawah.');
      return;
    }

    if (recognitionRef.current) {
      recognitionRef.current.abort();
      recognitionRef.current = null;
    }

    const rec = new Ctor();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = language;

    rec.onresult = (ev) => {
      let interim = '';
      for (let i = ev.resultIndex; i < ev.results.length; i++) {
        const res = ev.results[i];
        const text = res[0]?.transcript || '';
        if (res.isFinal) {
          setInterimTranscript('');
          void processTranscript(text);
        } else {
          interim += text;
        }
      }
      if (interim) setInterimTranscript(interim.trim());
    };

    rec.onerror = (ev) => {
      if (ev.error === 'not-allowed' || ev.error === 'service-not-allowed') {
        shouldKeepListeningRef.current = false;
        setIsListening(false);
        setLastError('Izin mikrofon untuk Voice Command ditolak browser.');
      } else if (ev.error !== 'no-speech' && ev.error !== 'aborted') {
        setLastError(`Speech error: ${ev.error}`);
      }
    };

    rec.onend = () => {
      if (shouldKeepListeningRef.current) {
        try {
          rec.start();
        } catch {
          setIsListening(false);
          shouldKeepListeningRef.current = false;
        }
      } else {
        setIsListening(false);
      }
    };

    shouldKeepListeningRef.current = true;
    setLastError(null);
    setIsListening(true);
    recognitionRef.current = rec;
    try {
      rec.start();
    } catch {
      setIsListening(false);
      shouldKeepListeningRef.current = false;
      setLastError('Gagal memulai pendengar suara.');
    }
  }, [language, processTranscript]);

  const stopListening = useCallback(() => {
    shouldKeepListeningRef.current = false;
    setIsListening(false);
    setInterimTranscript('');
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      recognitionRef.current = null;
    }
  }, []);

  const toggleListening = useCallback(() => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  }, [isListening, startListening, stopListening]);

  // Restart automatically if language changes while actively listening
  useEffect(() => {
    if (isListening) {
      stopListening();
      const t = window.setTimeout(() => startListening(), 120);
      return () => window.clearTimeout(t);
    }
  }, [language]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    return () => {
      shouldKeepListeningRef.current = false;
      recognitionRef.current?.abort();
    };
  }, []);

  return {
    isSupported,
    isListening,
    requireWakeWord,
    language,
    interimTranscript,
    lastError,
    isProcessingAi,
    history,
    setRequireWakeWord,
    setLanguage,
    toggleListening,
    submitManualCommand: processTranscript,
  };
}
