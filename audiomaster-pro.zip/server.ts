import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

function extractYouTubeId(input: string): string | null {
  const trimmed = input.trim();
  if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) return trimmed;
  try {
    const url = new URL(trimmed);
    if (url.hostname.includes('youtu.be')) {
      const id = url.pathname.replace('/', '').slice(0, 11);
      return /^[a-zA-Z0-9_-]{11}$/.test(id) ? id : null;
    }
    const v = url.searchParams.get('v');
    if (v && /^[a-zA-Z0-9_-]{11}$/.test(v)) return v;
    const match = url.pathname.match(/\/(?:embed|shorts|live)\/([a-zA-Z0-9_-]{11})/);
    if (match) return match[1];
  } catch {
    const match = trimmed.match(/(?:v=|youtu\.be\/|embed\/|shorts\/)([a-zA-Z0-9_-]{11})/);
    if (match) return match[1];
  }
  return null;
}

async function startServer() {
  const app = express();
  const httpServer = http.createServer(app);
  app.use(express.json({ limit: '2mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, service: 'AudioMaster Pro' });
  });

  // Resolve real YouTube video metadata via official oEmbed
  app.get('/api/youtube/resolve', async (req, res) => {
    const rawUrl = String(req.query.url || '');
    const videoId = extractYouTubeId(rawUrl);
    if (!videoId) {
      res.status(400).json({ error: 'URL atau ID video YouTube tidak valid.' });
      return;
    }

    const watchUrl = `https://www.youtube.com/watch?v=${videoId}`;
    try {
      const response = await fetch(
        `https://www.youtube.com/oembed?url=${encodeURIComponent(watchUrl)}&format=json`
      );
      if (!response.ok) {
        res.json({
          videoId,
          title: `YouTube Stream (${videoId})`,
          author: 'YouTube',
          thumbnailUrl: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
        });
        return;
      }
      const data = (await response.json()) as {
        title?: string;
        author_name?: string;
        thumbnail_url?: string;
      };
      res.json({
        videoId,
        title: data.title || `YouTube Stream (${videoId})`,
        author: data.author_name || 'YouTube',
        thumbnailUrl: data.thumbnail_url || `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
      });
    } catch {
      res.json({
        videoId,
        title: `YouTube Stream (${videoId})`,
        author: 'YouTube',
        thumbnailUrl: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
      });
    }
  });

  // Gemini AI: Automated Vocal Mastering & Smart Harmony Preset Generator
  app.post('/api/ai/mastering-preset', async (req, res) => {
    if (!process.env.GEMINI_API_KEY) {
      res.status(503).json({
        error: 'GEMINI_API_KEY belum dikonfigurasi pada Settings > Secrets.',
      });
      return;
    }

    const { songTitle = '', genre = 'Pop Karaoke', vocalStyle = 'Balanced Studio', notes = '' } = req.body || {};

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: `Analisis kebutuhan mastering vokal dan harmoni DSP real-time untuk sesi karaoke / produksi berikut:
Judul Lagu / Konteks YouTube: "${songTitle || 'Live Vocal Session'}"
Genre: "${genre}"
Karakter Vokal Target: "${vocalStyle}"
Catatan Tambahan: "${notes || 'Tidak ada'}"

Berikan parameter DSP presisi untuk AudioMaster Pro:
- detectedKeyIndex: 0=C, 1=C#, 2=D, 3=D#, 4=E, 5=F, 6=F#, 7=G, 8=G#, 9=A, 10=A#, 11=B
- compressor: thresholdDb (-32 sampai -6), ratio (2 sampai 8), attackMs (3 sampai 25), releaseMs (60 sampai 260), makeupDb (0 sampai 9)
- vocalEq: lowDb (-6 sampai 6), midDb (-6 sampai 6), highDb (-4 sampai 8)
- youtubeEq: lowDb (-6 sampai 4), midDb (-6 sampai 2 untuk memberi ruang vokal), highDb (-4 sampai 4)
- harmonyMix (0.0 sampai 0.75), delayMix (0.05 sampai 0.55), delayTimeMs (120 sampai 420), autoDuckAmount (0.0 sampai 0.55)
- masteringNotes: ringkasan teknis singkat dalam Bahasa Indonesia (maksimal 2 kalimat).`,
        config: {
          systemInstruction:
            'Anda adalah Chief Mastering & DSP Audio Engineer profesional. Keluarkan hanya JSON valid sesuai skema tanpa markdown.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              presetName: { type: Type.STRING },
              detectedKeyIndex: { type: Type.INTEGER },
              scaleMode: { type: Type.STRING },
              harmonyInterval: { type: Type.STRING },
              harmonyMix: { type: Type.NUMBER },
              compressor: {
                type: Type.OBJECT,
                properties: {
                  thresholdDb: { type: Type.NUMBER },
                  ratio: { type: Type.NUMBER },
                  attackMs: { type: Type.NUMBER },
                  releaseMs: { type: Type.NUMBER },
                  makeupDb: { type: Type.NUMBER },
                },
                required: ['thresholdDb', 'ratio', 'attackMs', 'releaseMs', 'makeupDb'],
              },
              vocalEq: {
                type: Type.OBJECT,
                properties: {
                  lowDb: { type: Type.NUMBER },
                  midDb: { type: Type.NUMBER },
                  highDb: { type: Type.NUMBER },
                },
                required: ['lowDb', 'midDb', 'highDb'],
              },
              youtubeEq: {
                type: Type.OBJECT,
                properties: {
                  lowDb: { type: Type.NUMBER },
                  midDb: { type: Type.NUMBER },
                  highDb: { type: Type.NUMBER },
                },
                required: ['lowDb', 'midDb', 'highDb'],
              },
              delayMix: { type: Type.NUMBER },
              delayTimeMs: { type: Type.NUMBER },
              autoDuckAmount: { type: Type.NUMBER },
              masteringNotes: { type: Type.STRING },
            },
            required: [
              'presetName',
              'detectedKeyIndex',
              'scaleMode',
              'harmonyInterval',
              'harmonyMix',
              'compressor',
              'vocalEq',
              'youtubeEq',
              'delayMix',
              'delayTimeMs',
              'autoDuckAmount',
              'masteringNotes',
            ],
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim());
      res.json(parsed);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Gagal menghubungi layanan Gemini AI.';
      res.status(500).json({ error: message });
    }
  });

  // Gemini AI: Real-Time Telemetry Vocal Mastering & Audio Sync Diagnostics
  app.post('/api/ai/analyze-vocal', async (req, res) => {
    if (!process.env.GEMINI_API_KEY) {
      res.status(503).json({
        error: 'GEMINI_API_KEY belum dikonfigurasi pada Settings > Secrets.',
      });
      return;
    }

    const {
      rmsDb = -24,
      peakDb = -6,
      pitchHz = 0,
      detectedNote = '--',
      gainReductionDb = 0,
      syncDriftMs = 0,
      bufferFillPct = 50,
      youtubeTitle = 'Tidak ada lagu aktif',
    } = req.body || {};

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: `Evaluasi telemetri DSP audio real-time berikut dan berikan kalibrasi otomatis:
- Vocal RMS: ${rmsDb} dBFS
- Vocal Peak: ${peakDb} dBFS
- Pitch Terdeteksi: ${pitchHz} Hz (${detectedNote})
- Compressor Gain Reduction: ${gainReductionDb} dB
- Sinkronisasi YouTube-Vocal Drift: ${syncDriftMs} ms
- Ring Buffer Fill Level: ${bufferFillPct}%
- Lagu YouTube Aktif: "${youtubeTitle}"

Berikan diagnosis dan koreksi presisi dalam Bahasa Indonesia.`,
        config: {
          systemInstruction:
            'Anda adalah sistem Automated Vocal Mastering & Audio Sync Diagnostics. Berikan saran konkret berbasis angka telemetri.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              healthStatus: { type: Type.STRING },
              vocalDiagnosis: { type: Type.STRING },
              recommendedAction: { type: Type.STRING },
              suggestedThresholdDb: { type: Type.NUMBER },
              suggestedHighBoostDb: { type: Type.NUMBER },
              suggestedMidCutDb: { type: Type.NUMBER },
              suggestedSyncOffsetMs: { type: Type.NUMBER },
            },
            required: [
              'healthStatus',
              'vocalDiagnosis',
              'recommendedAction',
              'suggestedThresholdDb',
              'suggestedHighBoostDb',
              'suggestedMidCutDb',
              'suggestedSyncOffsetMs',
            ],
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim());
      res.json(parsed);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Gagal menganalisis telemetri vokal.';
      res.status(500).json({ error: message });
    }
  });

  // Gemini AI: Natural-language Voice Command DSP Intent Parser
  app.post('/api/ai/voice-command', async (req, res) => {
    if (!process.env.GEMINI_API_KEY) {
      res.status(503).json({
        error: 'GEMINI_API_KEY belum dikonfigurasi pada Settings > Secrets.',
      });
      return;
    }

    const { transcript = '' } = req.body || {};
    if (!String(transcript).trim()) {
      res.status(400).json({ error: 'Transkrip suara kosong.' });
      return;
    }

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: `Ubah perintah suara penyanyi/operator berikut menjadi aksi parameter DSP untuk AudioMaster Pro:
Ucapan: "${transcript}"

Aturan nilai:
- actionSummary: ringkasan singkat aksi (1 kalimat pendek).
- compressorEnabled: boolean opsional
- compressorThresholdDeltaDb: angka (-12 s/d +12) opsional
- compressorRatioDelta: angka (-4 s/d +4) opsional
- harmonyEnabled: boolean opsional
- harmonyMode: "smart_3rd" | "fifth" | "octave" | "duet" opsional
- harmonyKeyIndex: integer 0..11 (0=C, 1=C#, ..., 11=B) opsional
- harmonyMixDelta: angka (-0.5 s/d +0.5) opsional
- delayMixDelta: angka (-0.4 s/d +0.4) opsional
- vocalEqLowDelta: integer (-6 s/d +6) opsional
- vocalEqMidDelta: integer (-6 s/d +6) opsional
- vocalEqHighDelta: integer (-6 s/d +6) opsional
- autoMasterEnabled: boolean opsional
- youtubeMuted: boolean opsional
- youtubeGainDelta: angka (-0.5 s/d +0.5) opsional
- recordingAction: "start" | "stop" | "none"`,
        config: {
          systemInstruction:
            'Anda adalah parser perintah suara real-time untuk mixer vokal DSP. Hanya isi field yang relevan dengan ucapan pengguna.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              matched: { type: Type.BOOLEAN },
              actionSummary: { type: Type.STRING },
              compressorEnabled: { type: Type.BOOLEAN },
              compressorThresholdDeltaDb: { type: Type.NUMBER },
              compressorRatioDelta: { type: Type.NUMBER },
              harmonyEnabled: { type: Type.BOOLEAN },
              harmonyMode: { type: Type.STRING },
              harmonyKeyIndex: { type: Type.INTEGER },
              harmonyMixDelta: { type: Type.NUMBER },
              delayMixDelta: { type: Type.NUMBER },
              vocalEqLowDelta: { type: Type.INTEGER },
              vocalEqMidDelta: { type: Type.INTEGER },
              vocalEqHighDelta: { type: Type.INTEGER },
              autoMasterEnabled: { type: Type.BOOLEAN },
              youtubeMuted: { type: Type.BOOLEAN },
              youtubeGainDelta: { type: Type.NUMBER },
              recordingAction: { type: Type.STRING },
            },
            required: ['matched', 'actionSummary'],
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim());
      res.json(parsed);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Gagal memproses perintah suara AI.';
      res.status(500).json({ error: message });
    }
  });

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR === 'true' ? false : { server: httpServer },
        watch: process.env.DISABLE_HMR === 'true' ? null : undefined,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`AudioMaster Pro server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
